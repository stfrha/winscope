/*
//////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1999 - 2003 PHILIPS Semiconductors - APIC
//
// Module Name:
//
//     HAL4ATA.c
//
// Abstract:
//
//     This is HAL for IDE controllers.
//
// Author:
//
//     Hilbert Zhang ZhenYu
//
// Environment:
//
//     kernel mode only
//
// Notes:
//
// Revision History:
//     Create Date: Nov. 19 1999
//
//////////////////////////////////////////////////////////////////////////////
// Implementation Notes:
*/

#include <reg51.h>                /* special function register declarations   */

#undef   GLOBAL_EXT

#include "SysCnfg.h"

#include "BasicTyp.h"
#include "common.h"

#include "Hal4Sys.h"

#include "ATA.h"
#include "RBC.h"
#include "RBCCmd.h"
#include "Hal4ATA.h"

#include "TPBulk.h"

/*
//*************************************************************************
//  Public Data
//*************************************************************************
*/
STRUC_EXT TPBLK_STRUC	DATA_SEG	TPBulk_Block;
#define     TPBulk_CBW				TPBulk_Block.TPBulk_CommandBlock
#define	    RBC_CDB					TPBulk_CBW.cdbRBC
#define     RBC_LUN					TPBulk_CBW.bCBW_LUN
#define     TPBulk_CSW				TPBulk_Block.TPBulk_CommandStatus
#define     Hal4ATA_Atapi			RBC_CDB

STRUC_EXT   HW_ATA_DEVICES_EXTENSION	Hal4ATA_DevExt;
#define     ATADevExt_IDData            Hal4ATA_DevExt.IdentifyData

BIT_EXT     ATABF_IsAttached;
BIT_EXT     ATABF_IsSupportMultiSector;
BIT_EXT     ATABF_IDEXfer_dir;
BIT_EXT     ATABF_IsSkipSetParameters;

INT8_EXT    Hal4ATA_SectCntInBlk;
/*
//*************************************************************************
//  Private Data
//*************************************************************************
*/
// Static
INT8 BDATA_SEG	Hal4ATA_StatusByte;
sbit			Hal4ATA_StatusByte_ERR  = Hal4ATA_StatusByte^0;
sbit			Hal4ATA_StatusByte_IDX  = Hal4ATA_StatusByte^1;
sbit			Hal4ATA_StatusByte_CORR = Hal4ATA_StatusByte^2;
sbit			Hal4ATA_StatusByte_DRQ  = Hal4ATA_StatusByte^3;
sbit			Hal4ATA_StatusByte_DSC  = Hal4ATA_StatusByte^4;
sbit			Hal4ATA_StatusByte_DF   = Hal4ATA_StatusByte^5;
sbit			Hal4ATA_StatusByte_DRDY = Hal4ATA_StatusByte^6;
sbit			Hal4ATA_StatusByte_BSY  = Hal4ATA_StatusByte^7;

INT8 BDATA_SEG  Hal4ATA_DevReg = 0xA0;
sbit			Hal4ATA_DevReg_DEV  = Hal4ATA_DevReg^4;
sbit			Hal4ATA_DevReg_b5   = Hal4ATA_DevReg^5;
sbit			Hal4ATA_DevReg_LBA  = Hal4ATA_DevReg^6;
sbit			Hal4ATA_DevReg_b7   = Hal4ATA_DevReg^7;

// Temp
FLEXI_INT32		Hal4ATA_Track;
INT8			Hal4ATA_drvSelect;


/*

code LUT_DATA   lut_Data=
{
	0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,
    0x00, 0x80, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29, 0x00,

}

*/
/*
//*************************************************************************
//  Subroutines -- Level 1
//*************************************************************************
*/
void
Hal4ATA_GetStatus(void)
{
	Hal4ATA_StatusByte = Hal4Sys_ATAPortInB(ATAREG4IN_ALTERNATE_STATUS);
}

BOOLEAN
Hal4ATA_WaitOnBusyNDrdy(void)
{
    INT16   i;
    BOOLEAN retStatus = FALSE;
#ifndef DEBUG
    for (i = 250; i!=0; i--)
#else
    while(TRUE)
#endif
	{
		Hal4ATA_GetStatus();
		while ( Hal4ATA_StatusByte_DRDY !=1)
				{
					Hal4Sys_Wait4US();
					Hal4ATA_GetStatus();
					}

        // if IDE_STATUS_BUSY && !IDE_STATUS_DRDY
        //Hal4ATA_StatusByte_ERR  = Hal4ATA_StatusByte^0
/*
	if (Hal4ATA_StatusByte_ERR != 0 || Hal4ATA_StatusByte_DF != 0)
        {
            break;
        }
        else if(Hal4ATA_StatusByte_BSY !=0 || Hal4ATA_StatusByte_DRDY !=1)
			Hal4Sys_Wait4US();
        else
        {
            retStatus = TRUE;
            break;
        }

	}

	return retStatus;
*/
	retStatus = TRUE;
	break;
	}
	return retStatus;
}

BOOLEAN
Hal4ATA_WaitOnBusyNDrq(void)
{
    INT16   i;

    BOOLEAN retStatus = FALSE;
#ifndef DEBUG
    for (i = 25000; i!=0; i--)
#else
    while(TRUE)
#endif
	{

		Hal4ATA_GetStatus();

		while (Hal4ATA_StatusByte_DRQ !=1)
		{
			Hal4ATA_GetStatus();
		}

 /*
		if (Hal4ATA_StatusByte_ERR != 0 || Hal4ATA_StatusByte_DF != 0)
        {
            break;
        }
        else if(Hal4ATA_StatusByte_BSY !=0 || Hal4ATA_StatusByte_DRQ !=1)
			Hal4Sys_Wait4US();
        else
        {
            retStatus = TRUE;
            break;
        }
	}

*/
break;
}
    return TRUE;
}

BOOLEAN
Hal4ATA_WaitOnBusy(void)
{
    INT16 i;
  //  BOOLEAN retStatus = FALSE;

#ifndef DEBUG
    for (i = 25000; i!=0; i--)
#else
    while(TRUE)
#endif
	{
		Hal4ATA_GetStatus();
		while (Hal4ATA_StatusByte_BSY !=0)
			{
		//		Hal4Sys_Wait4US();
				Hal4ATA_GetStatus();
			}


/*
		if (Hal4ATA_StatusByte_ERR != 0 || Hal4ATA_StatusByte_DF != 0)
        {
            break;
        }
        else if(Hal4ATA_StatusByte_BSY)
        {
			Hal4Sys_Wait4US();
        }
		else
        {
            retStatus = TRUE;
			break;
        }
	}

   return retStatus;
*/

break;
}
return TRUE;

}

/*
BOOLEAN
Hal4ATA_WaitForDrq(void)
{
 //   INT16 w;
    BOOLEAN retStatus = FALSE;

//#ifndef DEBUG
//    for (w = 25000; w!=0; w--)
//#else
    while(TRUE)
//#endif
	{
		Hal4ATA_GetStatus();
	//	if (Hal4ATA_StatusByte_ERR != 0 || Hal4ATA_StatusByte_DF != 0)
    //    {
    //        break;
    //    }
    //    else if (Hal4ATA_StatusByte_DRQ != 1) //IDE_STATUS_DRQ
  //      if (Hal4ATA_StatusByte_DRQ != 1) //IDE_STATUS_DRQ
//			Hal4Sys_Wait4US();
//		else
//        {
//            retStatus = TRUE;
            break;
//        }
	}

    return retStatus;
}
*/

/*
//*************************************************************************
//  Subroutines -- Level 2
//*************************************************************************
*/
BOOLEAN
Hal4ATA_SelDevice(void)
{
    BOOLEAN retStatus = FALSE;
    if(Hal4ATA_WaitOnBusy())
    {

	// ATAREG4OUT_DEVICE_HEAD =  ATAREG_GRP0+6 = 0x56
	// ATAREG_GRP0 =0x50
	// BUFF_DIR_RD, !D12CS, !BUFF_EN, !IDE_CS1, !IDE_CS0,  A2, 	A1, A0
	//0x56		0		1		0			1		0		1	1	0

      Hal4Sys_ATAPortOutB(ATAREG4OUT_DEVICE_HEAD,Hal4ATA_DevReg);

        retStatus = Hal4ATA_WaitOnBusyNDrdy();
    }

    return retStatus;
}


/*
//*************************************************************************
//  Subroutines -- Level 3
//*************************************************************************
*/

BOOLEAN
Hal4ATA_IdeSoftReset(void)
{
    INT8 c;
    BOOLEAN retStatus = FALSE;

    Hal4ATA_DevReg_DEV = FALSE;
    if(Hal4ATA_SelDevice())
    {
	    /*
	    // SoftReset the device.
	    */
	    Hal4Sys_ATAPortOutB(ATAREG4OUT_CONTROL,IDE_DC_RESET_CONTROLLER|IDE_DC_DISABLE_INTERRUPTS );
	    Hal4Sys_WaitInUS(32); //>25US
	    Hal4Sys_ATAPortOutB(ATAREG4OUT_CONTROL,IDE_DC_REENABLE_CONTROLLER|IDE_DC_DISABLE_INTERRUPTS );

        for(c = 20; c != 0; c--)
    	    Hal4Sys_WaitInUS(50000); // 50MS

#ifndef DEBUG
        for(c = 31; c!=0; c--)  // 31 Seconds time out
#else
        while(TRUE)
#endif
        {
            if(Hal4ATA_WaitOnBusyNDrdy())
            {
                retStatus = TRUE;
                break;
            }
        }
    }
}


/*
//*************************************************************************
//  Subroutines -- level 4
//*************************************************************************
*/

BOOLEAN
Hal4ATA_IssueIDEIdentify(void)
{
    INT16 i;
    BOOLEAN retStatus = FALSE;
    // Select device.
	if(Hal4ATA_SelDevice())
    {
	    // Send IDE IDENTIFY command.
//	    IDE_COMMAND_IDENTIFY=0xEC ;
	    Hal4Sys_ATAPortOutB(ATAREG4OUT_COMMAND, IDE_COMMAND_IDENTIFY);

	    if(Hal4ATA_WaitOnBusyNDrq())
        {

            /*
	        // Suck out 256 words. After waiting for one model that asserts busy
	        // after receiving the Packet Identify command.
	        */
	        if(Hal4ATA_InitDevExt())
                retStatus = TRUE;
        }

	    /*
	    // Work around for some IDE and one model Atapi that will present more than
	    // 256 words for the Identify data.
	    */
	    for (i=10000; i != 0; i--)
        {
		    Hal4ATA_GetStatus();
		    if (Hal4ATA_StatusByte_DRQ)
            {
			    /*
			    // Suck out any remaining bytes and throw away.
			    */
			    Hal4Sys_ATADataPortInW();

		    }
		    else
			    break;
	    }
    }

	return retStatus;

} /* end IssueIdentify()*/

BOOLEAN
Hal4ATA_InitDevExt(void)
{
    INT8 c;
    if(Hal4ATA_WaitOnBusyNDrq())
    {
        ATADevExt_IDData.GeneralConfiguration = Hal4Sys_ATADataPortInW();//INT16  00
        ATADevExt_IDData.NumberOfCylinders = Hal4Sys_ATADataPortInW();//INT16  01
        Hal4Sys_ATADataPortInW();
        ATADevExt_IDData.NumberOfHeads = Hal4Sys_ATADataPortInW();//INT16  03

        for(c = 2 ; c != 0; c--)
            Hal4Sys_ATADataPortInW();
        ATADevExt_IDData.SectorsPerTrack = Hal4Sys_ATADataPortInW();//INT16  06

        for(c = 40 ; c != 0; c--) // 7 -47
            Hal4Sys_ATADataPortInW();
        ATADevExt_IDData.MaximumBlockTransfer = Hal4Sys_ATADataPortInW();//INT8 47

        Hal4Sys_ATADataPortInW(); // 48
        ATADevExt_IDData.Capabilities = Hal4Sys_ATADataPortInW();//INT16  49

        for(c = 4; c != 0; c--)
            Hal4Sys_ATADataPortInW();
        ATADevExt_IDData.NumberOfCurrentCylinders = Hal4Sys_ATADataPortInW();//INT16  54
        ATADevExt_IDData.NumberOfCurrentHeads = Hal4Sys_ATADataPortInW();//INT16  55
        ATADevExt_IDData.CurrentSectorsPerTrack = Hal4Sys_ATADataPortInW();//INT16  56
        ATADevExt_IDData.CurrentSectorCapacity.ints.i0 = Hal4Sys_ATADataPortInW();//INT32  57
        ATADevExt_IDData.CurrentSectorCapacity.ints.i1 = Hal4Sys_ATADataPortInW();//

        if(ATADevExt_IDData.CurrentSectorCapacity.u0 == 0)
        {
            ATADevExt_IDData.NumberOfCurrentCylinders = ATADevExt_IDData.NumberOfCylinders;
            ATADevExt_IDData.NumberOfCurrentHeads = ATADevExt_IDData.NumberOfHeads ;//INT16  55
            ATADevExt_IDData.CurrentSectorsPerTrack = ATADevExt_IDData.SectorsPerTrack;//INT16  56
            ATADevExt_IDData.CurrentSectorCapacity.u0 = (INT32)ATADevExt_IDData.NumberOfCurrentCylinders * ATADevExt_IDData.NumberOfCurrentHeads * ATADevExt_IDData.CurrentSectorsPerTrack;
        }
        return(TRUE);
    }
    else
        return(FALSE);

}

BOOLEAN
Hal4ATA_IsLBAmode(void)
{
//	if( ATADevExt_IDData.CurrentSectorCapacity.u0 >= ((INT32) 63<<14) ) /*63* 1024 * 16*/
//	{
        Hal4ATA_DevReg_LBA = 1;
//	}
//    else
//    {
//        Hal4ATA_DevReg_LBA = 0;
//    }
    return(Hal4ATA_DevReg_LBA);
}

BOOLEAN
Hal4ATA_IsModeOK(void)
{
	/*
	// This hideous hack is to deal with ESDI devices that return
	// garbage geometry in the IDENTIFY data.
	// This is ONLY for the crashdump environment as
	// these are ESDI devices.
	*/
    ATABF_IsSkipSetParameters = FALSE;


	if (Hal4ATA_DevExt.IdentifyData.SectorsPerTrack == 0x35 &&
		ATADevExt_IDData.NumberOfHeads == 0x07)
	{
		/*
		// Change these values to something reasonable.
		*/
		ATADevExt_IDData.SectorsPerTrack = 0x34;
		ATADevExt_IDData.NumberOfHeads = 0x0E;
	}

	if (ATADevExt_IDData.SectorsPerTrack == 0x35 &&
		ATADevExt_IDData.NumberOfHeads == 0x0F)
	{

		/*
		// Change these values to something reasonable.
		*/

		ATADevExt_IDData.SectorsPerTrack = 0x34;
		ATADevExt_IDData.NumberOfHeads = 0x0F;
	}

	if (ATADevExt_IDData.SectorsPerTrack == 0x36 &&
		ATADevExt_IDData.NumberOfHeads == 0x07)
	{

		/*
		// Change these values to something reasonable.
		*/
		ATADevExt_IDData.SectorsPerTrack = 0x3F;
		ATADevExt_IDData.NumberOfHeads = 0x10;
		ATABF_IsSkipSetParameters = TRUE;
	}

    return ATABF_IsSkipSetParameters;
}

BOOLEAN
Hal4ATA_SetFeature(void)
{
   Hal4Sys_ATAPortOutB(ATAREG4OUT_FEATURE,0x03);
   Hal4Sys_ATAPortOutB(ATAREG4OUT_SECTOR_COUNT, 0x08);

   Hal4Sys_ATAPortOutB(ATAREG4OUT_SECTOR_NUMBER,0);
   Hal4Sys_ATAPortOutB(ATAREG4OUT_CYLINDER_LOW,0);
   Hal4Sys_ATAPortOutB(ATAREG4OUT_CYLINDER_HIGH,0);

   Hal4Sys_ATAPortOutB(ATAREG4OUT_COMMAND, 0xEF);
}

BOOLEAN
Hal4ATA_SetDriveParameters(void)
{
    BOOLEAN retStatus = FALSE;

    if(Hal4ATA_WaitOnBusy())
    {
        /*
	    // Set up registers for SET PARAMETER command.
	    */
   	    //Hal4Sys_ATAPortOutB(ATAREG4OUT_DEVICE_HEAD,Hal4ATA_DevReg|(ATADevExt_IDData.NumberOfHeads-1) );
        Hal4Sys_ATAPortOutB(ATAREG4OUT_DEVICE_HEAD,0xef );
        //Hal4Sys_ATAPortOutB(ATAREG4OUT_SECTOR_COUNT,ATADevExt_IDData.SectorsPerTrack);
        Hal4Sys_ATAPortOutB(ATAREG4OUT_SECTOR_COUNT,0x20);

        if(Hal4ATA_WaitOnBusyNDrdy())
        {

	        /*
	        // Send SET PARAMETER command.
	        // IDE_COMMAND_SET_DRIVE_PARAMETERS 0x91 (Init Device Parameter)
	        */
	        Hal4Sys_ATAPortOutB(ATAREG4OUT_COMMAND,IDE_COMMAND_SET_DRIVE_PARAMETERS);

            retStatus = Hal4ATA_WaitOnBusy();
        }
    }
    return retStatus;
} /* end Hal4ATA_SetDriveParameters()*/


BOOLEAN
Hal4ATA_SetMultipleMode(void)  //IDE_COMMAND_SET_MULTIPLE=0xC6
{
    BOOLEAN retStatus = FALSE;
	if ( ATABF_IsAttached && Hal4ATA_SelDevice() )
	{
        if(ATADevExt_IDData.MaximumBlockTransfer > MULTI_BLOCK_1 )
        {
	//	    Hal4Sys_ATAPortOutB(ATAREG4OUT_SECTOR_COUNT, ATADevExt_IDData.MaximumBlockTransfer);
	//	    Hal4Sys_ATAPortOutB(ATAREG4OUT_COMMAND, IDE_COMMAND_SET_MULTIPLE);
            if( Hal4ATA_WaitOnBusy())
            {
                ATABF_IsSupportMultiSector = TRUE;
                retStatus = TRUE;
            }
            else
			{
                ATABF_IsSupportMultiSector = FALSE;
			}
		}
        else
        {
            ATABF_IsSupportMultiSector = FALSE;
        }

        if(ATABF_IsSupportMultiSector == FALSE)
        {
            retStatus = Hal4ATA_IdeSoftReset();
        }
	}

    return retStatus;
}

/*
//*************************************************************************
//  Subroutines -- level 5 ATA transaction
//*************************************************************************
*/
BOOLEAN
Hal4ATA_IdeHardReset(void)
{
    INT8 c,a,b,d,e;
    BOOLEAN retStatus = FALSE;


    ATA_RST_N = 0;
    Hal4Sys_WaitInUS(320); // >25 US
    ATA_RST_N = 1;
/*
	while (TRUE)
	{	a= Hal4Sys_ATAPortInB(ATAREG4IN_SECTOR_COUNT);
		b = Hal4Sys_ATAPortInB(ATAREG4IN_SECTOR_NUMBER);
		d = Hal4Sys_ATAPortInB(ATAREG4IN_CYLINDER_LOW);
		e = Hal4Sys_ATAPortInB(ATAREG4IN_CYLINDER_HIGH);

		if ( (d+e >0) && (a+b >2))
		{ATA_RST_N = 0;
	     Hal4Sys_WaitInUS(320); // >25 US
	     ATA_RST_N = 1;
	 	}
	 else
	 break;
	}
*/
    for(c = 20; c != 0; c--)
    	Hal4Sys_WaitInUS(50000); // 50MS

    if(Hal4ATA_SelDevice())
	{

    Hal4ATA_DevReg_DEV = FALSE;
    Hal4Sys_ATAPortOutB(ATAREG4OUT_DEVICE_HEAD,Hal4ATA_DevReg);
	}

#ifndef DEBUG
    for(c = 31; c!=0; c--)  // 31 Seconds time out
#else
    while(TRUE)
#endif
    {
        if(Hal4ATA_WaitOnBusyNDrdy())
        {
            retStatus = TRUE;
            break;
        }
    }

 //   MCU_P1 = D12REG_ONLY;
    return retStatus;
}

BOOLEAN
Hal4ATA_FindIDEDevice(void)
{

    INT8    c;

    ATABF_IsAttached = FALSE;
    Hal4ATA_DevReg_DEV = FALSE;

	if(Hal4ATA_IdeHardReset())
    {
	//	Hal4Sys_ATAPortOutB(ATAREG4OUT_CONTROL,0xFA);
		Hal4ATA_SetFeature();
	    for ( c = 2; c != 0; c--, Hal4ATA_DevReg_DEV^=1 )
	    {

            if(Hal4ATA_SelDevice())
            {
		        if ( Hal4ATA_IssueIDEIdentify() )
		        {
                    ATABF_IsAttached = TRUE;
                    break;
		        }
            }
	    }

        if(ATABF_IsAttached)
        {
            Hal4ATA_IsLBAmode();

            if(!Hal4ATA_DevReg_LBA)
            {
			    //  Being cautious,
                //  CHS Harddisk set block=1
    		    ATADevExt_IDData.MaximumBlockTransfer = 1;

            }


            if( Hal4ATA_IsModeOK() == FALSE)
            {
		        ATABF_IsAttached = Hal4ATA_SetDriveParameters();
            }

            if(ATABF_IsAttached)
            {
                ATABF_IsAttached = Hal4ATA_SetMultipleMode();
		    }

        } // IDE HD is found

//Hal4Sys_ATAPortOutB(ATAREG4OUT_CONTROL,0xFA);
    } // IDE Reset OK

//    MCU_P1 = D12REG_ONLY;   //D12REG_ONLY =0xB8

    return ATABF_IsAttached;


} /*end Hal4ATA_FindIDEDevice()*/


BOOLEAN
Hal4ATA_ReadWriteSetting(void)
{

    BOOLEAN retStatus = FALSE;
    /*
	// Select device  .
	*/
	if(Hal4ATA_SelDevice())
	//if(TRUE)
    {
        //Assume Sector Counter <256
        Hal4Sys_ATAPortOutB(ATAREG4OUT_SECTOR_COUNT, RBC_CDB.RbcCdb_Read.XferLength_0);


	    if(Hal4ATA_DevReg_LBA )
	    /* IN LBA mode */
	    {
		    /*
		    // Set up sector number register.
		    */
		    /* From Read Card Capacity()
cdbReadCap.tmpVar.CapData.LBA_3 =cdbReadCap.tmpVar.l0[1].chars0.c3;
cdbReadCap.tmpVar.CapData.LBA_2 =cdbReadCap.tmpVar.l0[1].chars0.c2;
cdbReadCap.tmpVar.CapData.LBA_1 =cdbReadCap.tmpVar.l0[1].chars0.c1;
cdbReadCap.tmpVar.CapData.LBA_0 =cdbReadCap.tmpVar.l0[1].chars0.c0;
			*/

//-----------------------------------------
		if( ATABF_IDEXfer_dir )    // ATABF_Xfer_dir==1 Read(from Dev to Host)
  		    {


		    Hal4Sys_ATAPortOutB(ATAREG4OUT_SECTOR_NUMBER,RBC_CDB.RbcCdb_Read.LBA.LBA_W8.LBA_0);
		    Hal4Sys_ATAPortOutB(ATAREG4OUT_CYLINDER_LOW,RBC_CDB.RbcCdb_Read.LBA.LBA_W8.LBA_1);
		    Hal4Sys_ATAPortOutB(ATAREG4OUT_CYLINDER_HIGH,RBC_CDB.RbcCdb_Read.LBA.LBA_W8.LBA_2);
            Hal4Sys_ATAPortOutB(ATAREG4OUT_DEVICE_HEAD, (RBC_CDB.RbcCdb_Read.LBA.LBA_W8.LBA_3&0x0f) | Hal4ATA_DevReg );


	    }
	    else
	    {
		    // write command.
		    Hal4Sys_ATAPortOutB(ATAREG4OUT_SECTOR_NUMBER,RBC_CDB.RbcCdb_Write.LBA.LBA_W8.LBA_0);
		    Hal4Sys_ATAPortOutB(ATAREG4OUT_CYLINDER_LOW,RBC_CDB.RbcCdb_Write.LBA.LBA_W8.LBA_1);
		    Hal4Sys_ATAPortOutB(ATAREG4OUT_CYLINDER_HIGH,RBC_CDB.RbcCdb_Write.LBA.LBA_W8.LBA_2);
            Hal4Sys_ATAPortOutB(ATAREG4OUT_DEVICE_HEAD, (RBC_CDB.RbcCdb_Write.LBA.LBA_W8.LBA_3&0x0f) | Hal4ATA_DevReg );
		    }

 //----------------------------------------
	    }
	    else
	    /* CHS mode */
	    {
		    /*
		    // Set up sector number register.
		    */
		    Hal4Sys_ATAPortOutB(ATAREG4OUT_SECTOR_NUMBER,(INT8) ((RBC_CDB.RbcCdb_Read.LBA.LBA_W32 % ATADevExt_IDData.SectorsPerTrack) + 1));

		    /*
		    // Caculate Hal4ATA_Track & Hal4ATA_drvSelect
		    */
		    Hal4ATA_Track.u0 = RBC_CDB.RbcCdb_Read.LBA.LBA_W32/((INT32)(ATADevExt_IDData.SectorsPerTrack));
		    Hal4ATA_drvSelect = (INT8)(Hal4ATA_Track.u0%ATADevExt_IDData.NumberOfHeads);
		    Hal4ATA_Track.u0 /= ((INT32)(ATADevExt_IDData.NumberOfHeads));

		    /*
		    // Set up cylinder low register.
		    */
		    Hal4Sys_ATAPortOutB(ATAREG4OUT_CYLINDER_LOW,Hal4ATA_Track.chars0.c0);
		    Hal4Sys_ATAPortOutB(ATAREG4OUT_CYLINDER_HIGH,Hal4ATA_Track.chars0.c1);

		    /*
		    // Set up head and drive select register.
		    */
            Hal4Sys_ATAPortOutB(ATAREG4OUT_DEVICE_HEAD, Hal4ATA_DevReg|Hal4ATA_drvSelect);
	    }

	    if( ATABF_IDEXfer_dir )    // ATABF_Xfer_dir==1 Read(from Dev to Host)
	    {
		    /*
		    // Send read command.
		    */
		 //   if (ATABF_IsSupportMultiSector)
		//	    Hal4Sys_ATAPortOutB(ATAREG4OUT_COMMAND, IDE_COMMAND_READ_MULTIPLE);
		//    else
			    Hal4Sys_ATAPortOutB(ATAREG4OUT_COMMAND, IDE_COMMAND_READ);
	    }
	    else
	    {
		    /*
		    // Send write command.
		    */
		  //  if (ATABF_IsSupportMultiSector)
		//	    Hal4Sys_ATAPortOutB(ATAREG4OUT_COMMAND,IDE_COMMAND_WRITE_MULTIPLE);
		//    else
			    Hal4Sys_ATAPortOutB(ATAREG4OUT_COMMAND,IDE_COMMAND_WRITE);
	    }

	    retStatus = Hal4ATA_WaitOnBusyNDrq();
    }

  //  MCU_P1 = D12REG_ONLY;
    return retStatus;

} /* end Hal4ATA_ReadWriteSetting()*/


