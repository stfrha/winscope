/*
//*************************************************************************
//
//                  P H I L I P S   P R O P R I E T A R Y
//
//           COPYRIGHT (c)   1999 BY PHILIPS SINGAPORE.
//                     --  ALL RIGHTS RESERVED  --
//
// File Name:	TPBulk.C
// Author:		ZhenYu Zhang
// Created:		Nov. 26, 1999
// Modified:
// Revision:    0.0
//
//*************************************************************************
//
// USB Mass Storage
//       Class Spec  1.0 Oct. 1998
//       Bulk Only Transport 1.0 Jun.21 1999
//
// Notes:
//   3. Share Mem between CBW & CSW to minimize Operations as well as RAM
//   2. CSW structure size is 13[0xd] bytes
//   1. bInterfaceProtocol for Bulk-Only Transport
//           0x50 = 'P'
//
//
//
*/

#include <reg51.h>                /* special function register declarations   */

#undef  GLOBAL_EXT

#include "SysCnfg.h"
#include "BasicTyp.h"

#include "usb100.h"

#include "common.h"
#include "Hal4Sys.h"
#include "Hal4d12.h"

#include "ATA.h"
#include "RBCCmd.h"
#include "RBC.h"
#include "HAL4ATA.h"

#include "MainLoop.h"
#include "Chap_9.h"
#include "TPBulk.h"

/*
//*************************************************************************
//  Public Data
//*************************************************************************
*/

// bit Flags
STRUC_EXT BITFLAGS BDATA_SEG bFlags;

// MCU Timer bit flags
BIT_EXT         MCUBF_Timer;
INT8_EXT        Hal4Sys_ClockTicks;

// D12 bit flags
BIT_EXT         D12BF_SetupOverwritten;
BIT_EXT         D12BF_Configuration;

//USB
// DefaultControlPipe Finite State Machine [One-Hot]
INT8_EXT BDATA_SEG DCPFSMstate;
BIT_EXT     DCPFSM_SetupProc;
BIT_EXT     DCPFSM_DataIn;
BIT_EXT     DCPFSM_DataOut;
BIT_EXT     DCPFSM_COhandshake;
BIT_EXT     DCPFSM_CIhandshake;
BIT_EXT     DCPFSM_Stall;
//      DCP FSM
//      SETUP Stage -> SETUP Proc -> DATA OUT Stage -> CONTROL OUT Handshake -> STATUS Stage -> IDLE
//      SETUP Stage -> SETUP Proc -> CONTROL OUT Handshake -> STATUS Stage -> IDLE
//      SETUP Stage -> SETUP Proc -> DATA IN Stage-> CONTROL IN Handshake ->STATUS Stage -> IDLE
//
INT16_EXT	DCPXfer_wResidue;
INT8_EXT	* DCPXfer_pData;

// USB Device Request
STRUC_EXT   DEVICE_REQUEST DCPDeviceRequest;
INT8_EXT    UsbReq_Recipient;
INT8_EXT    UsbReq_Type;
INT8_EXT    UsbReq_Request;
BIT_EXT     REQBF_DCPRequest_dir;
BIT_EXT     REQBF_StallDCPRequest;
BIT_EXT     REQBF_DCPRequest_EPdir;

// Bulk-Only TP Finite State Machine [One-Hot]
INT8_EXT BDATA_SEG BOTFSMstate;
BIT_EXT     BOTFSM_CBWProc;
BIT_EXT     BOTFSM_DataIn;
BIT_EXT     BOTFSM_DataOut;
BIT_EXT     BOTFSM_CSWProc;
BIT_EXT     BOTFSM_CSW;
BIT_EXT     BOTFSM_IDLE;
BIT_EXT     BOTFSM_Stall;
//      BOT FSM
//      IDLE Stage ->  CBW -> CBW Proc -> DATA OUT Stage -> CSW Proc -> CSW Stage -> IDLE
//      IDLE Stage ->  CBW -> CBW Proc -> DATA IN Stage -> CSW Proc -> CSW Stage -> IDLE
//      STALL Stage ->  IDLE
//
INT16_EXT   BOTXfer_wResidue;
INT8_EXT    * BOTXfer_pData;
//INT8_EXT    * BOTXfer_pData;
STRUC_EXT TPBLK_STRUC	DATA_SEG	TPBulk_Block;
#define     TPBulk_CBW				TPBulk_Block.TPBulk_CommandBlock
#define	    RBC_CDB					TPBulk_CBW.cdbRBC
#define     RBC_LUN					TPBulk_CBW.bCBW_LUN
#define     TPBulk_CSW				TPBulk_Block.TPBulk_CommandStatus
BIT_EXT     BOTXfer_Abort;
BIT_EXT     BOTBF_StallAtBulkOut;
BIT_EXT     BOTBF_StallAtBulkIn;

// XferSpace
INT8_EXT BDATA_SEG Xfer_Space;
// DCPXfer space
BIT_EXT     DCPXfer_atMCUCODE;
BIT_EXT     DCPXfer_atMCURAM;
BIT_EXT     DCPXfer_atEEROM;
BIT_EXT     DCPXfer_atATA;
// Bulk Only Tranport Xfer Space
BIT_EXT     BOTXfer_atRAM;
BIT_EXT     BOTXfer_atATA;
BIT_EXT     BOTXfer_atROM;

/*
//*************************************************************************
//  Public temp var
//*************************************************************************
*/

//  Public temp var
STRUC_EXT   FLEXI_INT32 tempvars4UsbReq;
INT8_EXT BDATA_SEG FlexByte;
BIT_EXT     FlexByte_b0 ;
BIT_EXT     FlexByte_b1;
BIT_EXT     FlexByte_b2;
BIT_EXT     FlexByte_b3;
BIT_EXT     FlexByte_b4;
BIT_EXT     FlexByte_b5;
BIT_EXT     FlexByte_b6;
BIT_EXT     FlexByte_b7;


STRUC_EXT   HW_ATA_DEVICES_EXTENSION	Hal4ATA_DevExt;

/*
//*************************************************************************
//  Private Data
//*************************************************************************
*/


/*
//*************************************************************************
//  Class Request Subroutines
//  Public Functions
//*************************************************************************
*/

#define     USB_CLASS_REQUEST_USBSTOR_RESET         0xFF
#define     USB_CLASS_REQUEST_USBSTOR_GETMAXLUN     0xFE

/*
//*************************************************************************
//Bulk-Only TP-Bulk Hanlder
//*************************************************************************
*/
void TPBulk_CBWHandler( void )
{

	/*
	// Get CBW
	*/
	if(  sizeof(CBW) == Hal4D12_ReadEndpoint(4,EP2_PACKET_SIZE,(PINT8)&(TPBulk_CBW)) )
    {
	    if(TPBulksup_IsCBWValid())
	    {

			/*
			// for Valid CBW
			*/

		    RBC_Handler();
			return;
	    }
	}
	/*
	// for Invalid CBW
	// Stall Both Bulk Endpoints
	// Let host goto reset recovery sequence
	*/
	TPBulksup_ErrorHandler(CASECBW,0);
	RBC_BuildSenseData(SCSI_SENSE_ILLEGAL_REQUEST,SCSI_ADSENSE_ILLEGAL_COMMAND,0);
	TPBulk_CSWHandler();// Goto USBFSM4BOT_CSWPROC;
}

void
TPBulksup_ErrorHandler(INT8 HostDevCase,INT16 wByteCounterDevWillXfer)
{
	TPBulk_CSW.dCSW_DataResidue = TPBulk_CBW.dCBW_DataXferLen - wByteCounterDevWillXfer;

	switch(HostDevCase)
	{
	case CASEOK:
	case CASE1:     /* Hn=Dn*/
	case CASE6:     /* Hi=Di*/
		TPBulk_CSW.bCSW_Status = CSW_GOOD;
		break;
	case CASE12:    /* Ho=Do*/
		TPBulk_CSW.bCSW_Status = CSW_GOOD;
		break;

	case CASE2:     /* Hn<Di*/
	case CASE3:     /* Hn<Do*/

		//BOTBF_StallAtBulkIn = 1; // may or may-not
		TPBulk_CSW.bCSW_Status = CSW_PHASE_ERROR;
		break;

	case CASE4:     /* Hi>Dn*/
	case CASE5:     /* Hi>Di*/


		BOTBF_StallAtBulkIn = 1;
		TPBulk_CSW.bCSW_Status = CSW_FAIL;//CSW_GOOD or CSW_FAIL
		break;


	case CASE7:     /* Hi<Di*/
	case CASE8:     /* Hi<>Do */

		//BOTBF_StallAtBulkIn = 1; // may or may-not
		TPBulk_CSW.bCSW_Status = CSW_PHASE_ERROR;
		break;

	case CASE9:     /* Ho>Dn*/
	case CASE11:    /* Ho>Do*/

        //BOTBF_StallAtBulkOut = 1; // may or may-not
		TPBulk_CSW.bCSW_Status = CSW_FAIL;//CSW_GOOD or CSW_FAIL
		break;

	case CASE10:    /* Ho<>Di */
	case CASE13:    /* Ho<Do*/

		//TBF_StallAtBulkIn = 1;// may or may-not
        //TBF_StallAtBulkOut = 1;// may or may-not
		TPBulk_CSW.bCSW_Status = CSW_PHASE_ERROR;
		break;

	case CASECBW:   /* invalid CBW */

        BOTBF_StallAtBulkIn = 1;
		BOTBF_StallAtBulkOut = 1;

		TPBulk_CSW.bCSW_Status = CSW_PHASE_ERROR;
		break;

	case CASECMDFAIL:

        BOTBF_StallAtBulkIn = 1;
		TPBulk_CSW.bCSW_Status = CSW_FAIL;
		break;

	default:
		break;
	}

	TPBulk_CSW.dCSW_Signature = CSW_SIGNATURE;
//	TPBulk_CSW.dCSW_Tag = TPBulk_CBW.dCBW_Tag;

}

void TPBulk_CSWHandler( void )
{

	if(BOTBF_StallAtBulkIn)
    {
    	Hal4D12_SetEndpointStatus(5,1);//Bulk-In
	//    BOTFSMstate = USBFSM4BOT_STALL;
	//	BOTFSMstate	=USBFSM4BOT_CSWPROC; //USBFSM4BOT_CSWPROC=0x10
		TPBulk_CSW.dCSW_DataResidue += BOTXfer_wResidue;

	#ifdef BIG_ENDIAN
			TPBulk_CSW.dCSW_DataResidue = Hal4Sys_SwapINT32(TPBulk_CSW.dCSW_DataResidue);
	#endif
			Xfer_Space &= BOTXFERSPACE_MASK;
			BOTXfer_atRAM = 1;
			BOTXfer_pData = (PINT8) &TPBulk_CSW;
		    BOTXfer_wResidue = sizeof(CSW);

    }
	else if(BOTBF_StallAtBulkOut)
    {
    	Hal4D12_SetEndpointStatus(4,1);//Bulk-Out
	    BOTFSMstate = USBFSM4BOT_STALL;
    }
    else
    {

		TPBulk_CSW.dCSW_DataResidue += BOTXfer_wResidue;

#ifdef BIG_ENDIAN
		TPBulk_CSW.dCSW_DataResidue = Hal4Sys_SwapINT32(TPBulk_CSW.dCSW_DataResidue);
#endif
		Xfer_Space &= BOTXFERSPACE_MASK;
		BOTXfer_atRAM = 1;
		BOTXfer_pData = (PINT8) &TPBulk_CSW;
	    BOTXfer_wResidue = sizeof(CSW);

	    BOTFSMstate = USBFSM4BOT_CSW;
    }

}
/*
//*************************************************************************
//Bulk-Only TP - Class Request   Handler
//*************************************************************************
*/
void TPBulk_ResetATA(void)
/*
// HardReset
//  Clear All buffers
//  Reset Device
//
//  No changing on STALL or  toggle conditions.
*/
{
    /*
    // reset ATA controller
    */
    Hal4ATA_IdeHardReset();

    Chap9sup_SingleTransmitEP0(0,0);
}

void TPBulk_GetMaxLUN(void)
{
  //  INT8    c = 0;
  //  Chap9sup_SingleTransmitEP0(&c,1);
      	Hal4D12_StallEP0();

}
/*
//*************************************************************************
//Bulk Only Transport support functions
//*************************************************************************
*/
INT8 TPBulksup_ReadFrBOEP(INT8 Length)
/*
//  TPBulkXfer
//  Length
*/
{

	if(Length>EP2_PACKET_SIZE)
		Length = EP2_PACKET_SIZE;

	if( BOTXfer_atROM )
		Length = Hal4D12_ReadEPAtCode(4,Length);
	else if(BOTXfer_atRAM)
		Length = Hal4D12_ReadEndpoint(4,Length,BOTXfer_pData);
//	else if(BOTXfer_atATA)


	return Length;
}

INT8 TPBulksup_WriteToBIEP(INT8 Length)
{

	if(Length > EP2_PACKET_SIZE)
		Length = EP2_PACKET_SIZE;

	if( BOTXfer_atROM )
		Length = Hal4D12_WriteEPAtCode(5,Length,BOTXfer_pData);
	else if(BOTXfer_atRAM)
		Length = Hal4D12_WriteEndpoint(5,Length,BOTXfer_pData  );
//	else if(BOTXfer_atATA)

	return Length;
}


BOOLEAN TPBulksup_IsCBWValid( void)
{

#ifdef BIG_ENDIAN
	TPBulk_CBW.dCBW_DataXferLen = Hal4Sys_SwapINT32(TPBulk_CBW.dCBW_DataXferLen);
#endif

	if( TPBulk_CBW.dCBW_Signature == CBW_SIGNATURE \
        && TPBulk_CBW.bCBW_LUN <= 1 \
        && TPBulk_CBW.bCBW_CDBLen <= MAX_CDBLEN )
		return(1);
	else
		return(0);
}
