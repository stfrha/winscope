/*
   //*************************************************************************
   //
   //                  P H I L I P S   P R O P R I E T A R Y
   //
   //           COPYRIGHT (c)   1999 BY PHILIPS SINGAPORE.
   //                     --  ALL RIGHTS RESERVED  --
   //
   // File Name:	    ISR.C
   // Author:           Hilbert Zhang ZhenYu
   //                   Chew Thing Piao
   // Created:          Oct. 1 99
   // Modified:
   // Revision: 		0.0.
   //
   //*************************************************************************
   //
   //*************************************************************************
   */
#include <reg51.h>                /* special function register declarations   */

#undef   GLOBAL_EXT

#include "SysCnfg.h"
#include "BasicTyp.h"

#include "Common.h"
#include "Hal4Sys.h"
#include "Hal4d12.h"

/*
//*************************************************************************
//  Public data
//*************************************************************************
*/
// bit Flags
STRUC_EXT BITFLAGS  bFlags;

// Timer 0
BIT_EXT             MCUBF_Timer;
INT8_EXT            Hal4Sys_ClockTicks;

// D12 bit flags
BIT_EXT D12BF_SetupOverwritten;
BIT_EXT D12BF_Configuration;

// DefaultControlPipe Finate State Machine [One-Hot]
INT8_EXT BDATA_SEG  DCPFSMstate;
BIT_EXT             DCPFSM_SetupProc;
BIT_EXT             DCPFSM_Datain;
BIT_EXT             DCPFSM_Dataout;
BIT_EXT             DCPFSM_COhandshake;
BIT_EXT             DCPFSM_CIhandshake;
BIT_EXT             DCPFSM_Stall;

INT8_EXT BDATA_SEG  BOTFSMstate;
BIT_EXT             DCPFSM_CBWProc;
BIT_EXT             BOTFSM_DataIn;
BIT_EXT             BOTFSM_DataOut;
BIT_EXT             BOTFSM_CSWProc;
BIT_EXT             BOTFSM_CSW;
BIT_EXT             BOTFSM_Stall;

// USB Device Request
STRUC_EXT DEVICE_REQUEST DCPDeviceRequest;
INT8_EXT            UsbReq_Recipient;
INT8_EXT            UsbReq_Type;
INT8_EXT            UsbReq_Request;
BIT_EXT             REQBF_DCPRequest_dir;
BIT_EXT             REQBF_DCPRequest_EPdir;
BIT_EXT             REQBF_StallDCPRequest;

// Default Control Pipe Tansfer DCPXfer
INT8_EXT BDATA_SEG  Xfer_Space;
BIT_EXT             DCPXfer_atMCUCODE;
BIT_EXT             DCPXfer_atMCURAM;
BIT_EXT             DCPXfer_atEEROM;
BIT_EXT             DCPXfer_atATA;
BIT_EXT             DCPXfer_atATASTR;

INT16_EXT           DCPXfer_wResidue;
INT8_EXT            * DCPXfer_pData;

/*
//*************************************************************************
//  Private data
//*************************************************************************
*/
INT8 BDATA_SEG          ISR_eplts ;
sbit D12EP0LTS_SUCCESS = ISR_eplts^0;
sbit D12EP0LTS_SETUP = ISR_eplts^5;

INT16 BDATA_SEG         ISR_IR;			// bit addressable data(16bits) from $20H->

sbit D12IS_EOT          = ISR_IR^0;     // D12 Interrupt Src
sbit D12IS_SUSPENDCHANGE= ISR_IR^15;    // D12 Interrupt Src
sbit D12IS_BUSRESET     = ISR_IR^14;    // D12 Interrupt Src
sbit D12IS_ENDP2IN      = ISR_IR^13;    // D12 Interrupt Src
sbit D12IS_ENDP2OUT     = ISR_IR^12;    // D12 Interrupt Src
sbit D12IS_ENDP1IN      = ISR_IR^11;    // D12 Interrupt Src
sbit D12IS_ENDP1OUT     = ISR_IR^10;    // D12 Interrupt Src
sbit D12IS_ENDP0IN      = ISR_IR^9;     // D12 Interrupt Src
sbit D12IS_ENDP0OUT     = ISR_IR^8;     // D12 Interrupt Src

/*
//*************************************************************************
// Private temp Var
//*************************************************************************
*/

/*
//*************************************************************************
//  Private Functions
//*************************************************************************
*/

void ep0_txdone(void);
void ep0_rxdone(void);

void ep1_txdone(void);
void ep1_rxdone(void);

/*
//*************************************************************************
//  Functions
//*************************************************************************
*/

timer_isr() interrupt 1
{
	RaiseIRQL();

#ifdef WORK_AT_12MHZ
    TIMER0_LOW = 0x00;    // 1 MS interval @12MHz
	TIMER0_HIGH =TIMER0_AT12MHZ;   // 0xFC
#endif

#ifdef WORK_AT_24MHZ
    TIMER0_LOW = 0x00;    // 1 MS interval @24MHz
    TIMER0_HIGH =TIMER0_AT24MHZ;    // 0xF8
#endif

#ifdef WORK_AT_36MHZ
    TIMER0_LOW = 0x00;    // 1 MS interval @36MHz
    TIMER0_HIGH =TIMER0_AT36MHZ;
#endif

#ifdef WORK_AT_48MHZ
    TIMER0_LOW = 0x00;    // 1 MS interval @48MHz
    TIMER0_HIGH =TIMER0_AT48MHZ;
#endif

    Hal4Sys_ClockTicks++;

    MCUBF_Timer = 1;

    LowerIRQL();
}

usb_isr() interrupt 0
{
	INT8 tem1 ;

	RaiseIRQL();

 //   tem1 = MCU_P1;
 //   tem2 = MCU_P2;
  //  tem3 = MCU_P3;
   // tem0 = MCU_P0;
 //   MCU_P1 = D12REG_ONLY;   // 0x38

	Hal4D12_ReadInterruptRegister(&ISR_IR);
	if(ISR_IR != 0)
    {
	    if(D12IS_BUSRESET)
        {
            DCPFSMstate = USBFSM4DCP_IDLE;   //USBFSM4DCP_IDLE =0x00
            BOTFSMstate = USBFSM4BOT_IDLE;  //USBFSM4BOT_IDLE =0x01
            D12BF_SetupOverwritten = 0;
            D12SUSPD = 1;
        }

//	    if(D12IS_EOT)
//		    dma_eot();


	    if(D12IS_SUSPENDCHANGE)
		   {
			   if(D12SUSPD == 1)
		   			{  //  In suspend state
		                            //    D12SUSPD = 0;
		                            //    MCU_D12CS= 0;
              		P0 = 0xFF;
					P1 = 0xFF;
					P2 = 0xFF;
					P3 = 0xFF;
                	PCON |= 0x02; //Powerdown bit set
					while (1);
					}
		}

		if(D12IS_ENDP0OUT)
			ep0_rxdone();
		if(D12IS_ENDP0IN)
			ep0_txdone();
		if(D12IS_ENDP1IN)
			ep1_txdone();
		if(D12IS_ENDP1OUT)
			ep1_rxdone();

	}

//	MCU_P2 =tem2;
//	MCU_P3 =tem3;
//	MCU_P0 =tem0;
    LowerIRQL();

//	MCU_P1 =tem1;
}

void ep0_rxdone(void)
{

	ISR_eplts = Hal4D12_ReadLastTransactionStatus(0); // Clear interrupt flag

    if (!D12EP0LTS_SUCCESS)
        return;

    if (D12EP0LTS_SETUP)
    {

        if(DCPFSM_SetupProc || DCPFSM_Dataout || DCPFSM_Datain )
        {
			D12BF_SetupOverwritten = 1;
        }

        DCPFSMstate = USBFSM4DCP_SETUPPROC;//USBFSM4DCP_SETUPPROC =0x01
	}
	else /* not a setup packet, just a Data Out Packet */
	{
        if (DCPFSM_CIhandshake)
        {
            /*
			// it may or may not be zero Length Packet in the STATUS stage of Get Command,
			*/
			/*
            // According to USB1.1 8.5.2.1
            // Any Length Pkt issued by host is taken as valid status stage
            */
			DCPFSMstate = USBFSM4DCP_IDLE;//USBFSM4BOT_IDLE =0x01
            /* D12 has Ack it in hardware, otherwise I cannot receive this interrupt*/
        }
        // else just let it stay in FIFO of Control-Out
    }
}

void ep0_txdone(void)
{

	ISR_eplts = Hal4D12_ReadLastTransactionStatus(1); // Clear interrupt flag

    if ( !D12EP0LTS_SUCCESS )
        return;

    if (DCPFSM_Datain)  //DCPFSM_DataIn = DCPFSMstate^1
    {
        if( DCPXfer_wResidue >= EP0_PACKET_SIZE)
	    {

            if(DCPXfer_atMCUCODE)
                Hal4D12_WriteEPAtCode(1, EP0_PACKET_SIZE, DCPXfer_pData);
            else if(DCPXfer_atMCURAM)
                Hal4D12_WriteEndpoint(1, EP0_PACKET_SIZE, DCPXfer_pData);
            else
                return;

			DCPXfer_pData += EP0_PACKET_SIZE;
            DCPXfer_wResidue -= EP0_PACKET_SIZE;

		    /*
		    // State remains at USBFSM4DCP_DATAIN
			*/
	    }
	    else if( DCPXfer_wResidue != 0)
	    {
            if(DCPXfer_atMCUCODE)
                Hal4D12_WriteEPAtCode(1, (INT8)DCPXfer_wResidue, DCPXfer_pData );
            else if(DCPXfer_atMCURAM)
                Hal4D12_WriteEndpoint(1, (INT8)DCPXfer_wResidue, DCPXfer_pData );
            else
                return;

			//DCPXfer_pData += DCPXfer_wResidue;
            DCPXfer_wResidue = 0;
			DCPFSMstate = USBFSM4DCP_HANDSHAKE4CI;
		}
	    else //  DCPXfer_wResidue == 0
	    {
            // Send zero packet at the end
            //
		    Hal4D12_WriteEndpoint(1, 0, 0);

		    DCPFSMstate = USBFSM4DCP_HANDSHAKE4CI;//USBFSM4DCP_HANDSHAKE4CI =0x10
	    }
    }
	else if( DCPFSM_COhandshake )
    {
    	DCPFSMstate = USBFSM4DCP_IDLE;//USBFSM4BOT_IDLE =0x01
    }
    // else just exit

#undef DCPXfer_wResidue
}


void ep1_txdone(void)
{
	Hal4D12_ReadLastTransactionStatus(3); /* Clear interrupt flag */
}

void ep1_rxdone(void)
{
	Hal4D12_ReadLastTransactionStatus(2); /* Clear interrupt flag */
}




