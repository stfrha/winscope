/*
   //*************************************************************************
   //
   //                  P H I L I P S   P R O P R I E T A R Y
   //
   //           COPYRIGHT (c)   1999 BY PHILIPS SINGAPORE.
   //                     --  ALL RIGHTS RESERVED  --
   //
   // File Name:	MainLoop.C
   // Author:       Hilbert Zhang ZhenYu
   // Created:      Nov. 19 99
   // Modified:
   // Revision: 	0.0.
   //
   //*************************************************************************
   // Implementation Notes:
   //
   //   4. Bulk-Only Transport FSM
   //      IDLE Stage ->  CBW -> CBW Proc -> DATA OUT Stage -> CSW Proc -> CSW Stage -> IDLE
   //      IDLE Stage ->  CBW -> CBW Proc -> DATA IN Stage -> CSW Proc -> CSW Stage -> IDLE
   //      STALL Stage ->  IDLE -> ...
   //
   //
   //   3. Default Control Pipe Finite State Machine
   //      SETUP Stage -> SETUP Proc -> DATA OUT Stage -> CONTROL OUT Handshake -> STATUS Stage -> IDLE
   //      SETUP Stage -> SETUP Proc -> CONTROL OUT Handshake -> STATUS Stage -> IDLE
   //      SETUP Stage -> SETUP Proc -> DATA IN Stage-> CONTROL IN Handshake ->STATUS Stage -> IDLE
   //      STALL -> SETUP Stage -> ...
   //
   //   2. Stack Overflow Avoidance.
   //      Setup TK overwritten allowance.
   //
   //   1. System Modeling
   //       A. D12
   //       B. 8051
   //       C. ATA controller emulation by 8051
   //
   //   0. 8051 Modeling
   //       A. Target 8051 , 128B RAM, 16KB ROM
   //       B. Choose 2 IRQL levels, Interrupt Priority 0 as IRQL_1, Mainloop as IRQL_0
   //       C. Bit Address Space, Byte Ram Addess Space, Code Address Space, IO port Space
   //
   //*************************************************************************
   // Development Environment
   //
   //   1. Use VC++ IDE instead of DOS enviroment
   //   0. Keil C Ver4
   //
   //*************************************************************************
*/

#include <reg51.h>                /* special function register declarations */

#define GLOBAL_EXT

#include "SysCnfg.h"
#include "BasicTyp.H"

#include "usb100.h"

#include "Common.h"
#include "Hal4Sys.h"
#include "Hal4d12.h"
#include "Hal4ata.h"

//#include "ATA.h"
#include "RBCCmd.h"
#include "RBC.h"

#include "mainloop.h"
#include "chap_9.h"
#include "TPBulk.h"

/*
//*************************************************************************
//  Public data
//*************************************************************************
*/

// bit Flags
STRUC_EXT BITFLAGS BDATA_SEG    bFlags;

// MCU Timer bit flags
BIT_EXT             MCUBF_Timer = bFlags.value^0;
INT8_EXT            Hal4Sys_ClockTicks = 0;

// D12 bit flags
BIT_EXT             D12BF_SetupOverwritten = bFlags.value^1;
BIT_EXT             D12BF_Configuration	 = bFlags.value^2;

//USB
// DefaultControlPipe Finite State Machine [One-Hot]
INT8_EXT BDATA_SEG  DCPFSMstate;
BIT_EXT             DCPFSM_SetupProc = DCPFSMstate^0;
BIT_EXT             DCPFSM_DataIn = DCPFSMstate^1;
BIT_EXT             DCPFSM_DataOut = DCPFSMstate^2;
BIT_EXT             DCPFSM_COhandshake = DCPFSMstate^3;
BIT_EXT             DCPFSM_CIhandshake = DCPFSMstate^4;
BIT_EXT             DCPFSM_Stall = DCPFSMstate^7;
//      DCP FSM
//      SETUP Stage -> SETUP Proc -> DATA OUT Stage -> CONTROL OUT Handshake -> STATUS Stage -> IDLE
//      SETUP Stage -> SETUP Proc -> CONTROL OUT Handshake -> STATUS Stage -> IDLE
//      SETUP Stage -> SETUP Proc -> DATA IN Stage-> CONTROL IN Handshake ->STATUS Stage -> IDLE
//

// USB Device Request
STRUC_EXT DEVICE_REQUEST DATA_SEG DCPDeviceRequest;
INT8_EXT            UsbReq_Recipient;
INT8_EXT            UsbReq_Type;
INT8_EXT            UsbReq_Request;
BIT_EXT             REQBF_DCPRequest_dir = bFlags.value^3;
BIT_EXT             REQBF_DCPRequest_EPdir = bFlags.value^4;
BIT_EXT             REQBF_StallDCPRequest = bFlags.value^5;

INT16_EXT           DCPXfer_wResidue;
INT8_EXT            * DCPXfer_pdata;

// Bulk-Only TP Finite State Machine [One-Hot]
INT8_EXT BDATA_SEG BOTFSMstate;
BIT_EXT             BOTFSM_IDLE = BOTFSMstate^0;
BIT_EXT             BOTFSM_CBWProc = BOTFSMstate^1;
BIT_EXT             BOTFSM_DataIn = BOTFSMstate^2;
BIT_EXT             BOTFSM_DataOut = BOTFSMstate^3;
BIT_EXT             BOTFSM_CSWProc = BOTFSMstate^4;
BIT_EXT             BOTFSM_CSW = BOTFSMstate^5;
BIT_EXT             BOTFSM_Stall = BOTFSMstate^7;
//      BOT FSM
//      IDLE Stage ->  CBW -> CBW Proc -> DATA OUT Stage -> CSW Proc -> CSW Stage -> IDLE
//      IDLE Stage ->  CBW -> CBW Proc -> DATA IN Stage -> CSW Proc -> CSW Stage -> IDLE
//      STALL Stage ->  IDLE
//
INT16_EXT   BOTXfer_wResidue;
INT8_EXT    * BOTXfer_pdata;
STRUC_EXT	TPBLK_STRUC	DATA_SEG	TPBulk_Block;
#define     TPBulk_CBW				TPBulk_Block.TPBulk_CommandBlock
#define	    RBC_CDB					TPBulk_CBW.cdbRBC
#define     RBC_LUN					TPBulk_CBW.bCBW_LUN
#define     Hal4ATA_Atapi			RBC_CDB
#define     TPBulk_CSW				TPBulk_Block.TPBulk_CommandStatus
BIT_EXT             BOTXfer_Abort = bFlags.value^8;
BIT_EXT             BOTBF_StallAtBulkOut = bFlags.value^6;
BIT_EXT             BOTBF_StallAtBulkIn = bFlags.value^7;

// Xfer_Space
INT8_EXT BDATA_SEG  Xfer_Space;
BIT_EXT             DCPXfer_atMCUCODE = Xfer_Space^0;
BIT_EXT             DCPXfer_atMCURAM = Xfer_Space^1;
BIT_EXT             DCPXfer_atEEROM = Xfer_Space^2;
BIT_EXT             DCPXfer_atATA = Xfer_Space^3;
BIT_EXT             BOTXfer_atRAM = Xfer_Space^4;
BIT_EXT             BOTXfer_atATA = Xfer_Space^5;
BIT_EXT             BOTXfer_atROM = Xfer_Space^6;


STRUC_EXT HW_ATA_DEVICES_EXTENSION	Hal4ATA_DevExt;
#define     ATADevExt_IDData		Hal4ATA_DevExt.IdentifyData

BIT_EXT             ATABF_IsAttached = bFlags.value^9;
BIT_EXT             ATABF_IsSupportMultiSector = bFlags.value^10;
BIT_EXT             ATABF_IDEXfer_dir = bFlags.value^11;
BIT_EXT             ATABF_IsSkipSetParameters = bFlags.value^12;

INT8_EXT            Hal4ATA_SectCntInBlk;
/*
//*************************************************************************
//  Public temp var
//*************************************************************************
*/

STRUC_EXT FLEXI_INT32 tempvars4UsbReq;

INT8_EXT BDATA_SEG  FlexByte;
BIT_EXT             FlexByte_b0 = FlexByte^0;
BIT_EXT             FlexByte_b1 = FlexByte^1;
BIT_EXT             FlexByte_b2 = FlexByte^2;
BIT_EXT             FlexByte_b3 = FlexByte^3;
BIT_EXT             FlexByte_b4 = FlexByte^4;
BIT_EXT             FlexByte_b5 = FlexByte^5;
BIT_EXT             FlexByte_b6 = FlexByte^6;
BIT_EXT             FlexByte_b7 = FlexByte^7;

//INT8_EXT            TempByte;


/*
//*************************************************************************
// USB protocol function pointer arrays
//*************************************************************************
*/

code void (*StandardDeviceRequest[MAX_STD_REQUEST])(void) =
{
	Chap9_GetStatus,
	Chap9_ClearFeature,
	MLsup_StallEP0,
	Chap9_SetFeature,
	MLsup_StallEP0,
	Chap9_SetAddress,
	Chap9_GetDescriptor,
	MLsup_StallEP0,
	Chap9_GetConfiguration,
	Chap9_SetConfiguration,
	Chap9_GetInterface,
	Chap9_SetInterface,
};

code void (*ClassDeviceRequest[MAX_CLASS_REQUEST])(void) =
{
	TPBulk_ResetATA,
    TPBulk_GetMaxLUN
};

/*
code void (*VendorDeviceRequest[MAX_VENDOR_REQUEST])(void) =
{
	MLsup_StallEP0
};
*/

/*
//*************************************************************************
//  Functions
//*************************************************************************
*/

void main(void)
{

    // Disable all Interrupts
    RaiseIRQL();

    // Init BitFlags
//    bFlags.value = 0;

    //Init 8051 ports;
	Hal4Sys_InitMCU();

    //Init Timer
	Hal4Sys_InitTimer0();

   Hal4Sys_InitD12();
   MLsup_ReconnectUSB();

  //Init IDE Harddisk
   Hal4ATA_FindIDEDevice();

	// Power-On Reset D12

    // Init FSM
	DCPFSMstate = USBFSM4DCP_IDLE;
    BOTFSMstate = USBFSM4BOT_IDLE;// USBFSM4BOT_IDLE=0x01
//BOTFSMstate =0;

	// Connect to USB Host


    /* Main program loop */
    while(TRUE)
    {
		// Enable Interrupt for Interrupt Type Event Stimulie
        LowerIRQL();  //LowerIRQL() == EA=1 , (no IRQ when EA=0!)

        // USB Control Pipe
        if (DCPFSM_SetupProc)	// DCPFSM_SetupProc=DCPFSMstate^0
        {
        	RaiseIRQL();
            MLsup_USBSetupTokenHandler();
            LowerIRQL();
		} // if SetupProc

		// USB Bulk Pipe
        RaiseIRQL();
        {
		//	 MCU_P1 = D12REG_ONLY;  // for read busy status
            if(BOTFSM_IDLE)   //BOTFSM_IDLE = BOTFSMstate^0
            {
			    Hal4Sys_D12CmdPortOutB( 0x04);// SelectEP BulkOut
			    FlexByte = Hal4Sys_D12DataPortInB();
                if(FlexByte_b0 == 1) // BulkOut Full
                    TPBulk_CBWHandler(); // Goto BOTFSMstate_CBWProc
            } // if BOT in IDLE

            while(BOTFSM_DataOut) //BOTFSM_DataOut = BOTFSMstate^3
            {

//                MCU_P1 = D12REG_ONLY;
                Hal4Sys_D12CmdPortOutB( 0x04);// SelectEP BulkOut
			    FlexByte = Hal4Sys_D12DataPortInB();
                if(FlexByte_b0 == 0) // if fifo is empty
                    break;

				Hal4Sys_D12CmdPortOutB( 0xF0);// ReadBuffer
				Hal4Sys_D12DataPortInB();// HI BYTE of Buffer Len
				FlexByte = Hal4Sys_D12DataPortInB();// LO BYTE of Buffer Len

				if(BOTXfer_atATA)   //BOTXfer_atATA = Xfer_Space^5
					MLsup_XferPktFrUSB2IDE();
				else if(BOTXfer_atRAM || BOTXfer_atROM)
					MLsup_XferPktFrUSB2MEM(FlexByte);

				BOTXfer_xdata += FlexByte;
				BOTXfer_wResidue -= FlexByte;
                if(BOTXfer_wResidue == 0)
                    { MCU_P1 = D12REG_ONLY;
                      TPBulk_CSWHandler(); // Goto BOTFSMstate_CSWProc
					 }
					//MCU_P1 = D12REG_ONLY;
            }//BOTFSM_DATAOUT


            while(BOTFSM_DataIn)//BOTFSM_DataIn = BOTFSMstate^2
            {
   //            MCU_P1 = D12REG_ONLY;
                Hal4Sys_D12CmdPortOutB( 0x05);// SelectEP BulkIn
	    		FlexByte = Hal4Sys_D12DataPortInB();
                if(FlexByte_b0 == 1) // BulkIn is full
                    break;


                if(BOTXfer_atATA)
				{
					MLsup_XferPktFrIDE2USB();
					FlexByte = EP2_PACKET_SIZE;
				}
				else if(BOTXfer_atRAM || BOTXfer_atROM)
					FlexByte = MLsup_XferPktFrMEM2USB();

				BOTXfer_pdata += FlexByte;
				BOTXfer_wResidue -= FlexByte;
                if(BOTXfer_wResidue == 0)
                 {// MCU_P1 = D12REG_ONLY;
                    TPBulk_CSWHandler();// Goto BOTFSMstate_CSWProc
			      }
    		} // BOTFSM_DataIn

		    if(BOTFSM_CSW)	//BOTFSM_CSW = BOTFSMstate^5
		    {
		//			MCU_P1 = D12REG_ONLY;

			    Hal4Sys_D12CmdPortOutB( 0x05);// SelectEP  BulkIn
			    FlexByte = Hal4Sys_D12DataPortInB();
			    if(FlexByte_b0 == 0) // BulkIn is empty
			    {

				    FlexByte = MLsup_XferPktFrMEM2USB();

				    BOTXfer_pdata += FlexByte;
				    BOTXfer_wResidue -= FlexByte;
				    if(BOTXfer_wResidue == 0)
					    BOTFSMstate = USBFSM4BOT_IDLE; // Goto BOTFSMstate_IDLE

			    }
		   }

        }
 //   	MCU_P1 = D12REG_ONLY;
       LowerIRQL();
	}
}


void MLsup_DisconnectUSB(void)
{
	RaiseIRQL();

    // Initialize D12 configuration
	Hal4D12_SetMode(D12_NOLAZYCLOCK, D12_SETTOONE | D12_CLOCK_4M);

}

void MLsup_ConnectUSB(void)
{
	// reset event flags
	RaiseIRQL();

	// No DMA, No IRQ from EPI4 & EPI5
	Hal4D12_SetDMA(0);

	// Initialize D12 configuration
	Hal4D12_SetMode(D12_NOLAZYCLOCK|D12_SOFTCONNECT, D12_SETTOONE | D12_CLOCK_4M);
}


void MLsup_ReconnectUSB(void)
{

    MLsup_DisconnectUSB();

    // Make sure disconnect time > 2.5 uS
    LowerIRQL();
    Hal4Sys_WaitInMS(10);
	MLsup_ConnectUSB();

}


void MLsup_USBSetupTokenHandler(void)
{

    D12BF_SetupOverwritten = 0;
    DCPXfer_wResidue = 0;

    tempvars4UsbReq.chars.c0 = Hal4D12_ReadEndpoint(0, sizeof(DEVICE_REQUEST),(INT8 *)(&(DCPDeviceRequest)));
	if( tempvars4UsbReq.chars.c0 == sizeof(DEVICE_REQUEST) )
	{


        DCPDeviceRequest.wValue = Hal4Sys_SwapINT16(DCPDeviceRequest.wValue);
		DCPDeviceRequest.wIndex = Hal4Sys_SwapINT16(DCPDeviceRequest.wIndex);
		DCPDeviceRequest.wLength = Hal4Sys_SwapINT16(DCPDeviceRequest.wLength);

        if(DCPDeviceRequest.bmRequestType & USB_ENDPOINT_DIRECTION_MASK)//USB_ENDPOINT_DIRECTION_MASK=0x80
		{
            // get command
            REQBF_DCPRequest_dir = 1;  // REQBF_DCPRequest_dir = bFlags.value^3
		}
		else
		{
			// Set command  without Data stage
            // or
			// Set command  with Data Buffer
            REQBF_DCPRequest_dir = 0;
		}

        if(DCPDeviceRequest.wIndex & USB_ENDPOINT_DIRECTION_MASK)
		{
            REQBF_DCPRequest_EPdir = 1;
		}
		else
		{
            REQBF_DCPRequest_EPdir = 0;
		}

        //	USBDeviceRequest_Handler();
        UsbReq_Recipient = DCPDeviceRequest.bmRequestType & USB_RECIPIENT;

        UsbReq_Type = DCPDeviceRequest.bmRequestType & USB_REQUEST_TYPE_MASK;
	    UsbReq_Request = DCPDeviceRequest.bRequest & USB_REQUEST_MASK;

        if ( REQBF_DCPRequest_dir || (DCPDeviceRequest.wLength == 0))
        {
            // For Get command via Control In
            // For Set command without Data Stage via Control Out
            // First of all, AckSetup to make it available for BUFFER fill in fifo
            MLsup_AcknowledgeSETUP(); // A needle hole for Setup TK overwritten
            if(D12BF_SetupOverwritten)
                return;
        }


        // REQBF_StallDCPRequest = 0; // has been cleared already!
        if ( (UsbReq_Type == USB_STANDARD_REQUEST) && (UsbReq_Request<MAX_STD_REQUEST))
        {
		    (*StandardDeviceRequest[UsbReq_Request])();
        }
	    else if((UsbReq_Type == USB_CLASS_REQUEST))
        {
            UsbReq_Request = 0xFF - UsbReq_Request;
            if(UsbReq_Request < MAX_CLASS_REQUEST)
            (*ClassDeviceRequest[UsbReq_Request])();
        }
/*	    else if((UsbReq_Type == USB_VENDOR_REQUEST) &&(UsbReq_Request<MAX_VENDOR_REQUEST))
        {
            (*VendorDeviceRequest[UsbReq_Request])();
        }
*/
        else
        {
		    REQBF_StallDCPRequest = 1;
        }

        if(REQBF_StallDCPRequest)
        {
            MLsup_StallEP0();
        }
        else if ( (!REQBF_DCPRequest_dir) && (DCPDeviceRequest.wLength != 0))
        {
            // For Set command with Data Stage via Control Out
            // First of all, AckSetup to make it available for Buffer Out Clearing
       		MLsup_AcknowledgeSETUP(); // A needle hole for Setup TK overwritten
        }
    }
	else
	{
		MLsup_StallEP0();
	}

}

void MLsup_AcknowledgeSETUP(void)
{
    // Give a needle hole for Setup Overwritten as well as ISR
    LowerIRQL();
    RaiseIRQL();
    if(!D12BF_SetupOverwritten)
        Hal4D12_AcknowledgeSETUP();
}

void MLsup_StallEP0(void)
{
    // Give a needle hole for Setup Overwritten as well as ISR
    LowerIRQL();
    RaiseIRQL();

    if(!D12BF_SetupOverwritten)
    {
        DCPFSMstate = USBFSM4DCP_STALL;
    	Hal4D12_StallEP0();
    }
}


void MLsup_XferPktFrUSB2MEM(INT8 Len)
{
	TPBulksup_ReadFrBOEP(Len);
}

INT8 MLsup_XferPktFrMEM2USB(void)
{
	if(BOTXfer_wResidue > EP2_PACKET_SIZE )
		return TPBulksup_WriteToBIEP(EP2_PACKET_SIZE);
	else
		return TPBulksup_WriteToBIEP((INT8)BOTXfer_wResidue);
}

#ifdef MAX_SPEED
//unsigned char c;
void MLsup_XferPktFrUSB2IDE(void)
{

    ATA_DATABUS_LO = 0xFF; // Give up DataBus, MCU_P2 = 0xFF;

    Hal4Sys_D12CmdPortOutB( 0xF2); //clear Buffer

    Hal4ATA_SectCntInBlk -- ;
    if( Hal4ATA_SectCntInBlk == 0)
    {
        Hal4ATA_SectCntInBlk = ATADevExt_IDData.MaximumBlockTransfer << BITNUM4EP2PKT_PER_SECTOR;
  //      Hal4ATA_WaitOnBusyNDrq();
 //  while(ATA_IORDY!=1);
  		  Hal4ATA_WaitOnBusy();
     }

}
#else
void MLsup_XferPktFrUSB2IDE(void)
{
    INT8    c0;

    MCU_P1 = D12REG_ATAREG4OUT;

    for(c0=EP2_PACKET_SIZE/2 ; c0!=0; c0--)
        MLsup_XferWordFrUSB2IDE();

    //MCU_P1 = D12REG_ONLY;
    ATA_DATABUS_LO = 0xFF; // Give up DataBus, MCU_P2 = 0xFF;

    Hal4Sys_D12CmdPortOutB( 0xF2); //clear Buffer

    Hal4ATA_SectCntInBlk -- ;
    if( Hal4ATA_SectCntInBlk == 0)
    {
        Hal4ATA_SectCntInBlk = ATADevExt_IDData.MaximumBlockTransfer << BITNUM4EP2PKT_PER_SECTOR;
        Hal4ATA_WaitOnBusyNDrq();
    }

}
#endif

#ifdef MAX_SPEED
	//unsigned char c;
void MLsup_XferPktFrIDE2USB(void)
{
//unsigned char c;
//	if (Hal4ATA_WaitForDrq()==0)
//	{
    //Hal4Sys_WaitInUS(32000); OK value
//    Hal4Sys_WaitInUS(32000); //>25US
//	}

	Hal4Sys_D12CmdPortOutB( 0xF0);// Write Buffer
	Hal4Sys_D12DataPortOutB(0);// HI BYTE of Buffer Len
	Hal4Sys_D12DataPortOutB(EP2_PACKET_SIZE);// LO BYTE of Buffer Len


    //MCU_P1 = ATAREG4IN_DATA;


    //MCU_P1 = D12REG_ONLY;
    Hal4Sys_D12CmdPortOutB( 0xFA); //valid Buffer

    Hal4ATA_SectCntInBlk -- ;
    if( Hal4ATA_SectCntInBlk == 0)
    {
        Hal4ATA_SectCntInBlk = ATADevExt_IDData.MaximumBlockTransfer << BITNUM4EP2PKT_PER_SECTOR;
     //   Hal4ATA_WaitOnBusyNDrq();
     Hal4ATA_WaitOnBusy();
    }
}
#else
void MLsup_XferPktFrIDE2USB(void)
{

    INT8 c0;

	Hal4Sys_D12CmdPortOutB( 0xF0);// Write Buffer
	Hal4Sys_D12DataPortOutB(0);// HI BYTE of Buffer Len
	Hal4Sys_D12DataPortOutB(EP2_PACKET_SIZE);// LO BYTE of Buffer Len

    MCU_P1 = ATAREG4IN_DATA;

    for(c0=EP2_PACKET_SIZE/2 ; c0!=0; c0--)
        MLsup_XferWordFrIDE2USB();

    //MCU_P1 = D12REG_ONLY;
    Hal4Sys_D12CmdPortOutB( 0xFA); //valid Buffer

    Hal4ATA_SectCntInBlk -- ;
    if( Hal4ATA_SectCntInBlk == 0)
    {
        Hal4ATA_SectCntInBlk = ATADevExt_IDData.MaximumBlockTransfer << BITNUM4EP2PKT_PER_SECTOR;
        Hal4ATA_WaitOnBusyNDrq();
    }
}
#endif

#ifndef MAX_SPEED
void MLsup_XferWordFrUSB2IDE(void)
{
    D12RD_N = 0;
    ATA_DATABUS_LO = D12_DATABUS;
    D12RD_N = 1;

    ATA_CS0_N = 0;
    ATA_WR_N = 0;  //ATA_WR_N==D12RD_N
//    while(ATA_IORDY!=1);
    ATA_WR_N = 1;  //ATA_WR_N==D12RD_N
    ATA_CS0_N = 1;
}

void MLsup_XferWordFrIDE2USB(void)
{
    MCU_P1 = ATAREG4IN_DATA;

    ATA_RD_N = 0;
//    while(ATA_IORDY!=1);
    FlexByte = ATA_DATABUS_HI;
//    TempByte = ATA_DATABUS_LO;
    ATA_RD_N = 1;

    MCU_P1 = D12REG_ONLY;

    //Hal4Sys_D12DataPortOutB(TempByte);
//    D12_DATABUS = TempByte;
    D12WR_N = 0;
    D12WR_N = 1;

    //Hal4Sys_D12DataPortOutB(TempByte);
    D12_DATABUS = FlexByte;
    D12WR_N = 0;
    D12WR_N = 1;

    D12_DATABUS = 0xFF; // Give up DataBus
}
#endif