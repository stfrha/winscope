/*
   //*************************************************************************
   //
   //                  P H I L I P S   P R O P R I E T A R Y
   //
   //           COPYRIGHT (c)   1999 BY PHILIPS SINGAPORE.
   //                     --  ALL RIGHTS RESERVED  --
   //
   // File Name:	    Hal4sys.C
   // Author:           Hilbert Zhang ZhenYu
   // Created:          Nov. 19, 99
   // Modified:
   // Revision: 		0.0.
   //
   //*************************************************************************
   //
   //*************************************************************************
   */
#include <reg51.h>                /* special function register declarations   */
#include <intrins.h>

#undef   GLOBAL_EXT

#include "SysCnfg.h"
#include "BasicTyp.H"

#include "Hal4Sys.h"

/*
   //*************************************************************************
   // Public Data
   //*************************************************************************
*/
// MCU Timer 0
INT8_EXT    Hal4Sys_ClockTicks;
//unsigned char IRQ_Reg_data;

/*
   //*************************************************************************
   // Functions
   //*************************************************************************
*/
void Hal4Sys_InitTimer0(void)
{
    //Init Timer0;
    TIMER0_MODE &= 0XF0;    // clear Timer 0 amd Keep Timer 1
	TIMER0_MODE |= 0X01;    // 16bit Timer
	TIMER0_PRIORITY = 0;    // 0 prority of Timer 0
	TIMER0_IRQ_ENABLE = 1;  // Enable IRQ Timer0

#ifdef WORK_AT_12MHZ
    TIMER0_LOW = 0x00;    // 1 MS interval @12MHz
	TIMER0_HIGH =TIMER0_AT12MHZ;
#endif

#ifdef WORK_AT_24MHZ
    TIMER0_LOW = 0x00;    // 1 MS interval @24MHz
    TIMER0_HIGH =TIMER0_AT24MHZ;
#endif

#ifdef WORK_AT_36MHZ
    TIMER0_LOW = 0x00;    // 1 MS interval @36MHz
    TIMER0_HIGH =TIMER0_AT36MHZ;
#endif

#ifdef WORK_AT_48MHZ
    TIMER0_LOW = 0x00;    // 1 MS interval @48MHz
    TIMER0_HIGH =TIMER0_AT48MHZ;
#endif

    TIMER0_START = 1;       // Start Timer 0
}

void Hal4Sys_Wait4US(void)
{
#ifdef WORK_AT_12MHZ
    // @12MHz
    // LCALL = 2 MC
    // RET = 2MC
#endif

#ifdef WORK_AT_24MHZ
    // @24MHz
    _nop_();
    _nop_();
    _nop_();
    _nop_();
#endif

#ifdef WORK_AT_36MHZ
    // @36MHz
    _nop_();
    _nop_();
    _nop_();
    _nop_();

    _nop_();
    _nop_();
    _nop_();
    _nop_();
#endif

#ifdef WORK_AT_48MHZ
    // @48MHz
    _nop_();
    _nop_();
    _nop_();
    _nop_();

    _nop_();
    _nop_();
    _nop_();
    _nop_();

    _nop_();
    _nop_();
    _nop_();
    _nop_();
#endif
}
void Hal4Sys_WaitInUS(INT16 time)
{

#ifdef WORK_AT_12MHZ
    time >>= 3; //time = time * MACHINECYCLE_AT12MHZ/LOOP_MC;
#endif

#ifdef WORK_AT_24MHZ
    time >>= 2; //time = time * MACHINECYCLE_AT24MHZ/LOOP_MC;
#endif

#ifdef WORK_AT_36MHZ
    time >>= 1; //time = time * MACHINECYCLE_AT36MHZ/LOOP_MC;
#endif

#ifdef WORK_AT_48MHZ
    time >>= 1; //time = time * MACHINECYCLE_AT48MHZ/LOOP_MC;
#endif

   for( ; time != 0; time -- );
 }


/*-----------------------------------------------------------
//    Address memory map
// 		D12_command	$101
//		D12_data	$100
//
//		ATA_error_reg 			$1F1 (read)
//		ATA_feature_reg			$1F1 (write)
//		ATA_sector_count_reg	$1F2 (read/write)
//		ATA_sector_number_reg	$1F3 (read/write)
//		ATA_Cylinder_low_reg	$1F4 (read/write)
//		ATA_Cylinder_high_reg	$1F5 (read/write)
//		ATA_drive/head_reg		$1F6 (read/write)
//		ATA_status_reg			$1F7 (read)
//		ATA_command_reg			$1F7 (write)
//		ATA_alternate_status_reg $3F6 (read)
//		ATA_device_control_reg	$3f6 (write)
//		ATA_drive_address_reg	$3f7 (read)

*/
void Hal4Sys_WaitInMS(INT8 time)
{
    LowerIRQL();
    time += Hal4Sys_ClockTicks;
	//while(Hal4Sys_ClockTicks != time );
}

/*  PIO mode for D12 access */

void Hal4Sys_D12CmdPortOutB( INT8 val)
{
//     	 unsigned char xdata *ext_address;
//	     ext_address=D12_command;
//	     *ext_address = val;              //   write cycle
  *((INT8 xdata *)D12_command) = val;

}

void Hal4Sys_D12DataPortOutB( INT8 val)
{
//    	 unsigned char xdata *ext_address;
//     ext_address=(D12_data&0xff00);
//	     *ext_address = val;              //   write cycle

  *((INT8 xdata *)D12_data) = val;

}

unsigned char Hal4Sys_D12DataPortInB( void)
{

//  	     unsigned char c;
//         unsigned char xdata *ext_address;
//         ext_address=(D12_data&0xff00);
//         c = *ext_address ;              //   read cycle
//       	 return c;
 return *((INT8 xdata *)D12_data);

}


void Hal4Sys_ATAPortOutB(INT16 Addr, INT8 Data)
{

//   		 unsigned char xdata *ext_address;
//   	     ext_address = (Addr & 0xff00);
//	     *ext_address = Data;
 *((INT8 xdata *)Addr) = Data;

}

INT8 Hal4Sys_ATAPortInB(INT16 Addr)
{
 		return *((INT8 xdata *)Addr);

}

INT16 Hal4Sys_ATADataPortInW(void)
{
 //    INT16 i;
 return  *((INT16 xdata *)ATAREG4IN_DATA);
 //    i += ( *((INT8 xdata *)ATAREG4IN_DATA2))<<8;    // HI = P0
 //    return(i);
}

/*
INT16 Hal4Sys_SwapINT16(INT16 wData)
{
    return ( (wData<<8)|(wData>>8) );
}

INT32 Hal4Sys_SwapINT32(INT32 dData)
{
    dData = (dData&0xff)<<24|(dData&0xff00)<<8|(dData&0xff000000)>>24|(dData&0xff0000)>>8;
	return dData;

}
*/

void Hal4Sys_ResetD12(void)
{
  //  D12CS_N  = 1; // CS disactive!!!
    D12RST_N = 0; // reset D12 , Holdup time > 2 uS.
   // Hal4Sys_Wait4US();
    Hal4Sys_WaitInMS(2000);
    D12RST_N = 1;
  //  D12CS_N  = 0;
    Hal4Sys_WaitInUS(400);
}

void Hal4Sys_InitD12(void)
{
    Hal4Sys_ResetD12();

    D12INT_EDGE = 0;        // Level trigle for D12INT_N
    D12INT_PRIORITY = 0;    // 0 Priority Level of D12INT_N
    D12INT_ENABLE = 1;      // Enalbe External IRQ0 for D12INT_N
}

