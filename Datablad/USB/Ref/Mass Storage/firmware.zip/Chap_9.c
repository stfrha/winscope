/*
   //*************************************************************************
   //
   //                  P H I L I P S   P R O P R I E T A R Y
   //
   //           COPYRIGHT (c)   1999 BY PHILIPS SINGAPORE.
   //                     --  ALL RIGHTS RESERVED  --
   //
   // File Name:	    CHAP_9.C
   // Author:           Hilbert Zhang ZhenYu
   // Created:          Oct. 1 99
   // Modified:
   // Revision: 		0.0.
   //
   //*************************************************************************
*/

#include <reg51.h>                /* special function register declarations   */

#undef   GLOBAL_EXT

#include "SysCnfg.h"
#include "BasicTyp.H"

#include "usb100.h"

#include "Common.h"
#include "Hal4Sys.h"
#include "Hal4d12.h"
#include "mainloop.h"
#include "chap_9.h"

/*
   //*************************************************************************
   // Public Data
   //*************************************************************************
*/

// bit Flags
STRUC_EXT BITFLAGS BDATA_SEG  bFlags;

// MCU Timer bit flags
BIT_EXT     MCUBF_Timer;
INT8_EXT   Hal4Sys_ClockTicks;

// D12 bit flags
BIT_EXT     D12BF_SetupOverwritten;
BIT_EXT     D12BF_Configuration;

//USB
// DefaultControlPipe Finite State Machine [One-Hot]
INT8_EXT BDATA_SEG DCPFSMstate;
BIT_EXT     DCPFSM_SetupProc;
BIT_EXT     DCPFSM_DataIn;
BIT_EXT     DCPFSM_DataOut;
BIT_EXT     DCPFSM_COhandshake;
BIT_EXT     DCPFSM_CIhandshake;
BIT_EXT     DCPFSM_Stall;
//      DCP FSM
//      SETUP Stage -> SETUP Proc -> DATA OUT Stage -> CONTROL OUT Handshake -> STATUS Stage -> IDLE
//      SETUP Stage -> SETUP Proc -> CONTROL OUT Handshake -> STATUS Stage -> IDLE
//      SETUP Stage -> SETUP Proc -> DATA IN Stage-> CONTROL IN Handshake ->STATUS Stage -> IDLE
//


// USB Device Request
STRUC_EXT   DEVICE_REQUEST DCPDeviceRequest;
INT8_EXT    UsbReq_Recipient;
INT8_EXT    UsbReq_Type;
INT8_EXT    UsbReq_Request;
BIT_EXT     REQBF_DCPRequest_dir;
BIT_EXT     REQBF_StallDCPRequest;
BIT_EXT     REQBF_DCPRequest_EPdir;


// Default Control Pipe Tansfer DCPXfer
INT8_EXT BDATA_SEG Xfer_Space;
BIT_EXT     DCPXfer_atMCUCODE;
BIT_EXT     DCPXfer_atMCURAM;
BIT_EXT     DCPXfer_atEEROM;
BIT_EXT     DCPXfer_atATA;

INT16_EXT  DCPXfer_wResidue;
INT8_EXT   * DCPXfer_pData;

// Bulk-Only TP Finite State Machine [One-Hot]
INT8_EXT BDATA_SEG BOTFSMstate;
BIT_EXT     BOTFSM_CBWProc;
BIT_EXT     BOTFSM_DataIn;
BIT_EXT     BOTFSM_DataOut;
BIT_EXT     BOTFSM_CSWProc;
BIT_EXT     BOTFSM_CSW;
BIT_EXT     BOTFSM_IDLE;
BIT_EXT     BOTFSM_Stall;
//      BOT FSM
//      IDLE Stage ->  CBW -> CBW Proc -> DATA OUT Stage -> CSW Proc -> CSW Stage -> IDLE
//      IDLE Stage ->  CBW -> CBW Proc -> DATA IN Stage -> CSW Proc -> CSW Stage -> IDLE
//      STALL Stage ->  IDLE
//
BIT_EXT     BOTBF_StallAtBulkOut;
BIT_EXT     BOTBF_StallAtBulkIn;

BIT_EXT     BOTXfer_atRAM;
BIT_EXT     BOTXfer_atATA;
BIT_EXT     BOTXfer_atROM;


/*
//*************************************************************************
//  Public temp var
//*************************************************************************
*/

//  Public temp var
STRUC_EXT   FLEXI_INT32 tempvars4UsbReq;
INT8_EXT BDATA_SEG FlexByte;
BIT_EXT     FlexByte_b0 ;
BIT_EXT     FlexByte_b1;
BIT_EXT     FlexByte_b2;
BIT_EXT     FlexByte_b3;
BIT_EXT     FlexByte_b4;
BIT_EXT     FlexByte_b5;
BIT_EXT     FlexByte_b6;
BIT_EXT     FlexByte_b7;


/*
   //*************************************************************************
   // Private temp var
   //*************************************************************************
*/

/*
   //*************************************************************************
   // USB Device Descriptor
   //*************************************************************************
*/

code USB_DEVICE_DESCRIPTOR DeviceDescr =
{
	sizeof(USB_DEVICE_DESCRIPTOR),
	USB_DEVICE_DESCRIPTOR_TYPE,
	SWAP(0x0100),
    0,
	0,
	0,
	EP0_PACKET_SIZE,
    SWAP(0x0584),   // PHILIPS VID
    SWAP(0x0001),   // Mass PID
    //SWAP(0x0471),   // PHILIPS VID
    //SWAP(0xFFF0),   // Mass PID
	SWAP(0x0100),
    STR_INDEX_MANUFACTURER,
	STR_INDEX_PRODUCT,
	STR_INDEX_SERIALNUMBER,
    1
};

#define NUM_ENDPOINTS	2

#define CONFIG_DESCRIPTOR_LENGTH    (sizeof(USB_CONFIGURATION_DESCRIPTOR) + sizeof(USB_INTERFACE_DESCRIPTOR) + (NUM_ENDPOINTS * sizeof(USB_ENDPOINT_DESCRIPTOR)))

code USB_CONFIGURATION_DESCRIPTOR ConfigDescr =
{
    sizeof(USB_CONFIGURATION_DESCRIPTOR),
    USB_CONFIGURATION_DESCRIPTOR_TYPE,
    SWAP(CONFIG_DESCRIPTOR_LENGTH),
	1,
	1,
    0,      //STR_INDEX_CONFIGURATION,
	0x80,
	0x32     // zero power consumption
};

code USB_INTERFACE_DESCRIPTOR InterfaceDescr =
{
    sizeof(USB_INTERFACE_DESCRIPTOR),
    USB_INTERFACE_DESCRIPTOR_TYPE,
    0,
    0,
	NUM_ENDPOINTS,
	USB_CLASS_CODE_MASSSTORAGE_CLASS_DEVICE,
//	USB_SUBCLASS_CODE_RBC,
	USB_SUBCLASS_CODE_SCSI,
	USB_PROTOCOL_CODE_BULK,
//	USB_SUBCLASS_CODE_SCSI,
    0   //	STR_INDEX_INTERFACE
};

code USB_ENDPOINT_DESCRIPTOR EP2_TXDescr =
{
	sizeof(USB_ENDPOINT_DESCRIPTOR),
	USB_ENDPOINT_DESCRIPTOR_TYPE,
	0x82,
	USB_ENDPOINT_TYPE_BULK,
	SWAP(EP2_PACKET_SIZE),
	0
};

code USB_ENDPOINT_DESCRIPTOR EP2_RXDescr =
{
	sizeof(USB_ENDPOINT_DESCRIPTOR),
	USB_ENDPOINT_DESCRIPTOR_TYPE,
	0x2,
	USB_ENDPOINT_TYPE_BULK,
	SWAP(EP2_PACKET_SIZE),
	0
};


code USB_STRING_LANGUAGE_DESCRIPTOR  strLanguage =
{
	sizeof(USB_STRING_LANGUAGE_DESCRIPTOR),
	USB_STRING_DESCRIPTOR_TYPE,
	SWAP(0x0409)
};

code USB_STRING_MANUFACTURER_DESCRIPTOR  strManufacturer =
{
	sizeof(USB_STRING_MANUFACTURER_DESCRIPTOR),
	USB_STRING_DESCRIPTOR_TYPE,
	{
	'P', 0,
	'h', 0,
	'i', 0,
	'l', 0,
	'i', 0,
	'p', 0,
	's', 0,
	' ', 0,
	'A', 0,
	'P', 0,
	'I', 0,
	'C', 0}
};

code USB_STRING_PRODUCT_DESCRIPTOR  strProduct =
{
	sizeof(USB_STRING_PRODUCT_DESCRIPTOR),
	USB_STRING_DESCRIPTOR_TYPE,
	{
	'U', 0,
	'S', 0,
	'B', 0,
	'-', 0,
	'I', 0,
	'D', 0,
	'E', 0,
	' ', 0,
	'A', 0,
	'd', 0,
	'a', 0,
	'p', 0,
	't', 0,
	'e', 0,
    'r', 0}
};

code USB_STRING_SERIALNUMBER_DESCRIPTOR  strSerialNum =
{
	sizeof(strSerialNum),
	USB_STRING_DESCRIPTOR_TYPE,
   {
	'0',0,
	'0',0,
	'0',0,
	'0',0,

	'0',0,
	'0',0,
	'0',0,
	'0',0,

	'0',0,
	'0',0,
	'0',0,
	'0',0}
};

/*
   //*************************************************************************
   // USB standard device requests
   //*************************************************************************
*/
void Chap9_SetAddress(void)
{
    Hal4D12_SetAddressEnable((INT8)(DCPDeviceRequest.wValue &
	    DEVICE_ADDRESS_MASK), 1);

    Chap9sup_SingleTransmitEP0(0,0);
}

void Chap9_GetInterface(void)
{
	tempvars4UsbReq.chars.tx0 = 0;        /* Only/Current interface = 0 */

    Chap9sup_SingleTransmitEP0(&tempvars4UsbReq.chars.tx0,1);
}

void Chap9_SetInterface(void)
{
	if (DCPDeviceRequest.wValue == 0 && DCPDeviceRequest.wIndex == 0)
    {
        Chap9sup_SingleTransmitEP0(0,0);
    }
    else
        REQBF_StallDCPRequest = 1;
}

void Chap9_GetConfiguration(void)
{
	tempvars4UsbReq.chars.tx0 = D12BF_Configuration;

	if (DCPDeviceRequest.wValue == 0 && DCPDeviceRequest.wIndex == 0 && DCPDeviceRequest.wLength == 1)
    {
        Chap9sup_SingleTransmitEP0(&tempvars4UsbReq.chars.tx0,1);
    }
    else
    {
        REQBF_StallDCPRequest = 1;
    }
}

void Chap9_SetConfiguration(void)
{
    if(DCPDeviceRequest.wIndex == 0 && DCPDeviceRequest.wLength == 0)
    {
	    if (DCPDeviceRequest.wValue == 0) {
		    /* put device in unconfigured state */
		    D12BF_Configuration = 0; /* This flag should be set before Unconfig and Config */
           	Hal4D12_SetEndpointEnable(0);	/* Disable all endpoints but EPP0. */
	    } else if (DCPDeviceRequest.wValue == 1) {
		    /* Configure device */
		    D12BF_Configuration = 1; /* This flag should be set before Unconfig and Config */
            Hal4D12_SetEndpointEnable(1);	/* Disable all endpoints but EPP0. */
	    } else
        {
            REQBF_StallDCPRequest = 1;
        }
    }
    else
    {
        REQBF_StallDCPRequest = 1;
    }

    if(!REQBF_StallDCPRequest)
        Chap9sup_SingleTransmitEP0(0,0);

}

void Chap9_GetStatus(void)
{
    if(DCPDeviceRequest.wValue == 0 && DCPDeviceRequest.wLength == 2 )
    {
		switch(UsbReq_Recipient)
		{
		case USB_RECIPIENT_DEVICE:
		    tempvars4UsbReq.chars.tx0 = DEVSTS_SELFPOWERED;   /* Self-powered*/
	        tempvars4UsbReq.chars.tx1=0;
			break;

        case USB_RECIPIENT_INTERFACE:
			tempvars4UsbReq.ints.i1=0;
			break;

        case USB_RECIPIENT_ENDPOINT:
			tempvars4UsbReq.chars.endp = (INT8)(DCPDeviceRequest.wIndex & MAX_ENDPOINTS);
			if (REQBF_DCPRequest_EPdir)
				tempvars4UsbReq.chars.c0 = Hal4D12_SelectEndpoint((tempvars4UsbReq.chars.endp<<1)+ 1);	/* Control-in */
			else
				tempvars4UsbReq.chars.c0 = Hal4D12_SelectEndpoint(tempvars4UsbReq.chars.endp<<1);	/* Control-out */
			if(tempvars4UsbReq.chars.c0 & D12_STALL)
				tempvars4UsbReq.chars.tx0 = ENDPSTS_HALT;   /* Halt */
			else
				tempvars4UsbReq.chars.tx0 = 0;
			tempvars4UsbReq.chars.tx1 = 0;

            break;

        default:
            REQBF_StallDCPRequest = 1;
			break;
		}
	}
	else
	{
        REQBF_StallDCPRequest = 1;

	}

    if(!REQBF_StallDCPRequest)
    {
        Chap9sup_SingleTransmitEP0(&tempvars4UsbReq.chars.tx0,2);
    }

}

void Chap9_ClearFeature(void)
{
 	if( DCPDeviceRequest.wLength == 0 )
    {
		switch(UsbReq_Recipient)
		{
		case USB_RECIPIENT_DEVICE:
	        break;

        case USB_RECIPIENT_ENDPOINT:
			if(DCPDeviceRequest.wValue == USB_FEATURE_ENDPOINT_STALL) //USB_FEATURE_ENDPOINT_STALL=0x0000
            {
				tempvars4UsbReq.chars.endp = (INT8)(DCPDeviceRequest.wIndex & MAX_ENDPOINTS);
                if(!D12BF_SetupOverwritten)
                {
		            if (REQBF_DCPRequest_EPdir)
                    {
					    /* clear TX stall for IN on EPn. */
					    Hal4D12_SetEndpointStatus((tempvars4UsbReq.chars.endp<<1)+1, 0);
						if(tempvars4UsbReq.chars.endp == 2)
						{
							BOTBF_StallAtBulkIn = 0;
							//if(BOTBF_StallAtBulkOut == 0)
								BOTFSMstate = USBFSM4BOT_CSW;
						}
				    }
				    else
				    {
					    /* clear RX stall for OUT on EPn. */
					    Hal4D12_SetEndpointStatus((tempvars4UsbReq.chars.endp<<1), 0);
						if(tempvars4UsbReq.chars.endp == 2)
						{
							BOTBF_StallAtBulkOut = 0;
							//if(BOTBF_StallAtBulkIn == 0)
							//	BOTFSMstate = USBFSM4BOT_IDLE;
						}
				    }
                }
			}
			else
			{
                REQBF_StallDCPRequest = 1;
			}
			break;

        default:
            REQBF_StallDCPRequest = 1;
			break;
		}
	}
	else
	{
        REQBF_StallDCPRequest = 1;
	}

    if(!REQBF_StallDCPRequest)
    {
        Chap9sup_SingleTransmitEP0(0,0);
    }
}

void Chap9_SetFeature(void)
{
	if( DCPDeviceRequest.wLength == 0 )
	{
		switch(UsbReq_Recipient)
		{
		case USB_RECIPIENT_DEVICE:
			if(DCPDeviceRequest.wValue == USB_FEATURE_REMOTE_WAKEUP)
            {
                REQBF_StallDCPRequest = 1;
            }
			break;

        case USB_RECIPIENT_ENDPOINT:
			if( DCPDeviceRequest.wValue == USB_FEATURE_ENDPOINT_STALL)
			{
				tempvars4UsbReq.chars.endp = (INT8)(DCPDeviceRequest.wIndex & MAX_ENDPOINTS);
                if(!D12BF_SetupOverwritten)
                {
		            if (REQBF_DCPRequest_EPdir)
                    {
			            /* clear TX stall for IN on EPn. */
   				        Hal4D12_SetEndpointStatus((tempvars4UsbReq.chars.endp<<1)+1, 1);
                    }
                    else
                    {
                        /* clear RX stall for OUT on EPn. */
   				        Hal4D12_SetEndpointStatus((tempvars4UsbReq.chars.endp<<1), 1);

                    }
                }
			}
			else
			{
                REQBF_StallDCPRequest = 1;
			}
			break;

        default:
            REQBF_StallDCPRequest = 1;
			break;
		}
	}
    else
	{
        REQBF_StallDCPRequest = 1;
	}

    if(!REQBF_StallDCPRequest)
        Chap9sup_SingleTransmitEP0(0,0);
}


void Chap9_GetDescriptor(void)
{
	tempvars4UsbReq.ints.i1 = DCPDeviceRequest.wValue; // wValue has be swapped.

    switch(tempvars4UsbReq.Descriptor.Type)
    {
    case USB_DEVICE_DESCRIPTOR_TYPE:
        DCPXfer_wResidue = sizeof(USB_DEVICE_DESCRIPTOR);
	    DCPXfer_pData = (INT8 code *)&DeviceDescr;
        break;
    case USB_CONFIGURATION_DESCRIPTOR_TYPE:
        DCPXfer_wResidue = CONFIG_DESCRIPTOR_LENGTH;
	    DCPXfer_pData = (INT8 code *)&ConfigDescr;
        break;
    case USB_STRING_DESCRIPTOR_TYPE:
        switch( tempvars4UsbReq.Descriptor.Index )
        {
        case STR_INDEX_LANGUAGE:
        	DCPXfer_wResidue = sizeof(USB_STRING_LANGUAGE_DESCRIPTOR);
	        DCPXfer_pData = (INT8 code *)&strLanguage;
            break;
        case STR_INDEX_MANUFACTURER:
       	    DCPXfer_wResidue = sizeof(USB_STRING_MANUFACTURER_DESCRIPTOR);
	        DCPXfer_pData = (INT8 code *)&strManufacturer;
            break;
        case STR_INDEX_PRODUCT:
           	DCPXfer_wResidue = sizeof(USB_STRING_PRODUCT_DESCRIPTOR);
	        DCPXfer_pData = (INT8 code *)&strProduct;
            break;
        case STR_INDEX_SERIALNUMBER:
        	DCPXfer_wResidue = sizeof(USB_STRING_SERIALNUMBER_DESCRIPTOR);
	        DCPXfer_pData = (INT8 code *)&strSerialNum;
            break;
        default:
            REQBF_StallDCPRequest = 1;
            break;
        }

        break;
    default:
        REQBF_StallDCPRequest = 1;
        break;
    }

    if(!REQBF_StallDCPRequest)
    {
        Chap9sup_BurstTransmitEP0();
    }
}



/*
   //*************************************************************************
   // Chap9 support functions
   //*************************************************************************
*/

void Chap9sup_SingleTransmitEP0(INT8 * buf, INT8 len)
{

    DCPXfer_wResidue = len;
    Xfer_Space &= DCPXFERSPACE_MASK;
    Xfer_Space |= DCPXFERSPACE_MCURAM;
    if(DCPXfer_wResidue == 0)
    {
        DCPFSMstate = USBFSM4DCP_HANDSHAKE4CO; //USBFSM4DCP_HANDSHAKE4CO=0x08
    }
    else
    {
        DCPFSMstate = USBFSM4DCP_HANDSHAKE4CI;//USBFSM4DCP_HANDSHAKE4CI=0x10
    }

    Hal4D12_SingleTransmitEP0(buf, len);
}

void Chap9sup_BurstTransmitEP0( void )
{

    if(DCPXfer_wResidue > DCPDeviceRequest.wLength)
        DCPXfer_wResidue = DCPDeviceRequest.wLength;

    Xfer_Space &= DCPXFERSPACE_MASK;
    Xfer_Space |= DCPXFERSPACE_MCUCODE;
	if( DCPXfer_wResidue >= EP0_PACKET_SIZE)
    {

		DCPFSMstate = USBFSM4DCP_DATAIN;

        Hal4D12_WriteEPAtCode(1, EP0_PACKET_SIZE, DCPXfer_pData);
		DCPXfer_pData += EP0_PACKET_SIZE;
		DCPXfer_wResidue -= EP0_PACKET_SIZE;
	}
	else
	{

        Hal4D12_WriteEPAtCode(1, DCPXfer_wResidue, DCPXfer_pData );
		//DCPXfer_pData += DCPXfer_wResidue;
		DCPXfer_wResidue = 0;

		DCPFSMstate = USBFSM4DCP_HANDSHAKE4CI;
	}
}

