/*
   //*************************************************************************
   //
   //                  P H I L I P S   P R O P R I E T A R Y
   //
   //           COPYRIGHT (c)   1999 BY PHILIPS SINGAPORE.
   //                     --  ALL RIGHTS RESERVED  --
   //
   // File Name:	    Hal4D12.C
   // Author:           Hilbert Zhang ZhenYu
   // Created:          Nov. 19, 99
   // Modified:
   // Revision: 		0.0.
   //
   //*************************************************************************
   //
   //*************************************************************************
   */
#include <reg51.h>                /* special function register declarations   */

#undef   GLOBAL_EXT

#include "SysCnfg.h"

#include "BasicTyp.h"
#include "common.h"

#include "Hal4Sys.h"
#include "Hal4d12.h"



/*
   //*************************************************************************
   // Functions
   //*************************************************************************
*/

void Hal4D12_SetAddressEnable(INT8 bAddress, bit bEnable)
{

	Hal4Sys_D12CmdPortOutB( 0xD0);
	if(bEnable)
        bAddress |= 0x80;

    Hal4Sys_D12DataPortOutB( bAddress);
}

void Hal4D12_SetEndpointEnable(bit bEnable)
{

	Hal4Sys_D12CmdPortOutB( 0xD8);
	if(bEnable)
		Hal4Sys_D12DataPortOutB( 1);
	else
		Hal4Sys_D12DataPortOutB( 0);

}

void Hal4D12_SetMode(INT8 bConfig, INT8 bClkDiv)
{

	Hal4Sys_D12CmdPortOutB( 0xF3);
	Hal4Sys_D12DataPortOutB( bConfig);
	Hal4Sys_D12DataPortOutB( bClkDiv);

}

void Hal4D12_SetDMA(INT8 bMode)
{

	Hal4Sys_D12CmdPortOutB( 0xFB);
	Hal4Sys_D12DataPortOutB( bMode);

}

/*
INT8 Hal4D12_GetDMA(void)
{

	Hal4Sys_D12CmdPortOutB( 0xFB);
	return Hal4Sys_D12DataPortInB();

}
*/
void Hal4D12_ReadInterruptRegister( INT16 * pInterruptReg)
{

	Hal4Sys_D12CmdPortOutB( 0xF4);
	((PFLEXI_INT16) pInterruptReg)->chars.c0 = Hal4Sys_D12DataPortInB();
	((PFLEXI_INT16) pInterruptReg)->chars.c1 = Hal4Sys_D12DataPortInB();
}
/*
INT16 Hal4D12_ReadInterruptRegister(void)
{
	unsigned char bb;
	unsigned char aa;
	unsigned short jj;
	Hal4Sys_D12CmdPortOutB( 0xF4);
	jj=Hal4Sys_D12DataPortInB();
	jj<<=8;
	bb=Hal4Sys_D12DataPortInB();
	jj+=bb;
	return jj;
}
*/

INT8 Hal4D12_ReadLastTransactionStatus(INT8 bEndp)
{
	Hal4Sys_D12CmdPortOutB( 0x40|bEndp);
	return Hal4Sys_D12DataPortInB();
}

INT8 Hal4D12_SelectEndpoint(INT8 bEndp)
{

	Hal4Sys_D12CmdPortOutB( bEndp);
	return Hal4Sys_D12DataPortInB();
}

/*
INT8 Hal4D12_ReadEndpointStatus(INT8 bEndp)
{

	Hal4Sys_D12CmdPortOutB( 0x80|bEndp);
	return Hal4Sys_D12DataPortInB();

}
*/

void Hal4D12_SetEndpointStatus(INT8 bEndp, INT8 bStalled)
{

	Hal4Sys_D12CmdPortOutB( 0x40|bEndp);
	Hal4Sys_D12DataPortOutB( bStalled);

}

/*
void Hal4D12_SendResume(void)
{
	Hal4Sys_D12CmdPortOutB( 0xF6);
}
*/
INT8 Hal4D12_ReadEndpoint(INT8 endp, INT8 len, INT8 data * buf)
//INT8 Hal4D12_ReadEndpoint(INT8 endp, INT8 len, INT8 * buf)
{
    // using endp, len, buf as var

	Hal4Sys_D12CmdPortOutB( endp);
	if((Hal4Sys_D12DataPortInB() & D12_FULLEMPTY) == 0) {
		return D12_FIFOEMPTY;
	}

	Hal4Sys_D12CmdPortOutB( 0xF0);
	Hal4Sys_D12DataPortInB();
	endp = Hal4Sys_D12DataPortInB();

	if( endp > len)
        endp = len;
    else
        len = endp;

	for(; endp != 0 ; endp--, buf++ )
		*(buf) = Hal4Sys_D12DataPortInB();

	Hal4Sys_D12CmdPortOutB( 0xF2);

	return len ;
}

INT8 Hal4D12_ReadEPAtCode(INT8 endp, INT8 len)
{
    // using endp, len, buf as var

	Hal4Sys_D12CmdPortOutB( endp);
	if((Hal4Sys_D12DataPortInB() & D12_FULLEMPTY) == 0) {
		return D12_FIFOEMPTY;
	}

	Hal4Sys_D12CmdPortOutB( 0xF0);
	Hal4Sys_D12DataPortInB();
	endp = Hal4Sys_D12DataPortInB();

	if( endp > len)
        endp = len;
    else
        len = endp;

	for(; endp != 0 ; endp-- )
		Hal4Sys_D12DataPortInB();

	Hal4Sys_D12CmdPortOutB( 0xF2);

	return len ;
}

/*
void Hal4D12_ValidateBuffer(INT8 endp)
{

    // Select Endpoint
	Hal4Sys_D12CmdPortOutB( endp);

    // Valiate Buffer
	Hal4Sys_D12CmdPortOutB( 0xFA);

}

void Hal4D12_ClearBuffer(INT8 endp)
{

    // Select Endpoint
	Hal4Sys_D12CmdPortOutB( endp);

    // Clear Buffer
	Hal4Sys_D12CmdPortOutB( 0xF2);

}
*/
INT8 Hal4D12_WriteEndpoint(INT8 endp, INT8 len, INT8 idata * buf)
{

	Hal4Sys_D12CmdPortOutB( endp);
	Hal4Sys_D12DataPortInB();

	Hal4Sys_D12CmdPortOutB( 0xF0);

    endp = len;
	Hal4Sys_D12DataPortOutB( 0);
	Hal4Sys_D12DataPortOutB( endp);

	for( ; endp != 0; endp-- , buf++)
		Hal4Sys_D12DataPortOutB( *(buf) );

	Hal4Sys_D12CmdPortOutB( 0xFA); // validate buffer

	return len;
}

INT8 Hal4D12_WriteEPAtCode(INT8 endp, INT8 len, INT8 code * buf)
{
	Hal4Sys_D12CmdPortOutB( endp);
	Hal4Sys_D12DataPortInB();

    endp = len;
	Hal4Sys_D12CmdPortOutB( 0xF0);
	Hal4Sys_D12DataPortOutB( 0);
	Hal4Sys_D12DataPortOutB( endp);

	for(; endp != 0; endp-- , buf++)
		Hal4Sys_D12DataPortOutB( *(buf) );

	Hal4Sys_D12CmdPortOutB( 0xFA); // validate buffer

	return len;
}

void Hal4D12_AcknowledgeEndpoint(INT8 endp)
{
	Hal4Sys_D12CmdPortOutB( endp);
	Hal4Sys_D12CmdPortOutB( 0xF1);
	if(endp == 0)
		Hal4Sys_D12CmdPortOutB( 0xF2);
}


void Hal4D12_SingleTransmitEP0(INT8 * buf, INT8 len)
{
//	if( len <= EP0_PACKET_SIZE)
    {
		Hal4D12_WriteEndpoint(1, len, buf);
	}
}

void Hal4D12_AcknowledgeSETUP(void)
{
		Hal4D12_AcknowledgeEndpoint(0);
		Hal4D12_AcknowledgeEndpoint(1);
}


void Hal4D12_StallEP0(void)
{
	Hal4D12_SetEndpointStatus(0, 1);
	Hal4D12_SetEndpointStatus(1, 1);
}


