/*
////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1999-2003 PHILIPS Semiconductors - APIC
//
// Module Name:
//
//	rbc.c
//
// Abstract:
//
//    These are the structures and defines used in the Reduced Block Command set
//
// Author:
//
//     Hilbert Zhang ZhenYu
//
// Revision History:
//
//		Created  01 Jun. 1999
//
// Copyright @ 1999-2003, PHILIPS Semiconductors - APIC. All rights reserved.
//
*/

#include <reg51.h>                /* special function register declarations   */

#undef   GLOBAL_EXT

#include "SysCnfg.h"
#include "BasicTyp.h"
#include "common.h"

#include "Hal4D12.h"

#include "ATA.h"
#include "RBC.h"
#include "RBCCmd.h"
#include "Hal4ata.h"
#include "Hal4Sys.h"


#include "TPBulk.h"


/*
//*************************************************************************
//  Public Data
//*************************************************************************
*/

//sbit ATA_RD_N           = 0xB6;

// bit Flags
STRUC_EXT BITFLAGS BDATA_SEG bFlags;

// MCU Timer bit flags
BIT_EXT     MCUBF_Timer;
INT8_EXT   Hal4Sys_ClockTicks;

// D12 bit flags
BIT_EXT     D12BF_SetupOverwritten;
BIT_EXT     D12BF_Configuration;

//USB
// DefaultControlPipe Finite State Machine [One-Hot]
INT8_EXT BDATA_SEG DCPFSMstate;
BIT_EXT     DCPFSM_SetupProc;
BIT_EXT     DCPFSM_DataIn;
BIT_EXT     DCPFSM_DataOut;
BIT_EXT     DCPFSM_COhandshake;
BIT_EXT     DCPFSM_CIhandshake;
BIT_EXT     DCPFSM_Stall;
//      DCP FSM
//      SETUP Stage -> SETUP Proc -> DATA OUT Stage -> CONTROL OUT Handshake -> STATUS Stage -> IDLE
//      SETUP Stage -> SETUP Proc -> CONTROL OUT Handshake -> STATUS Stage -> IDLE
//      SETUP Stage -> SETUP Proc -> DATA IN Stage-> CONTROL IN Handshake ->STATUS Stage -> IDLE
//
INT16_EXT  DCPXfer_wResidue;
INT8_EXT   * DCPXfer_pData;


// USB Device Request
STRUC_EXT   DEVICE_REQUEST DCPDeviceRequest;
INT8_EXT    UsbReq_Recipient;
INT8_EXT    UsbReq_Type;
INT8_EXT    UsbReq_Request;
BIT_EXT     REQBF_DCPRequest_dir;
BIT_EXT     REQBF_StallDCPRequest;
BIT_EXT     REQBF_DCPRequest_EPdir;

// Bulk-Only TP Finite State Machine [One-Hot]
INT8_EXT BDATA_SEG BOTFSMstate;
BIT_EXT     BOTFSM_CBWProc;
BIT_EXT     BOTFSM_DataIn;
BIT_EXT     BOTFSM_DataOut;
BIT_EXT     BOTFSM_CSWProc;
BIT_EXT     BOTFSM_CSW;
BIT_EXT     BOTFSM_IDLE;
BIT_EXT     BOTFSM_Stall;
//      BOT FSM
//      IDLE Stage ->  CBW -> CBW Proc -> DATA OUT Stage -> CSW Proc -> CSW Stage -> IDLE
//      IDLE Stage ->  CBW -> CBW Proc -> DATA IN Stage -> CSW Proc -> CSW Stage -> IDLE
//      STALL Stage ->  IDLE
//
BIT_EXT     BOTXfer_Abort;
INT16_EXT   BOTXfer_wResidue;
INT8_EXT    * BOTXfer_pData;
STRUC_EXT TPBLK_STRUC	DATA_SEG	TPBulk_Block;
#define     TPBulk_CBW				TPBulk_Block.TPBulk_CommandBlock
#define		CBW_wXferLen			TPBulk_CBW.dCBW_DataXferLen
#define	    RBC_CDB					TPBulk_CBW.cdbRBC
#define     RBC_LUN					TPBulk_CBW.bCBW_LUN
#define     TPBulk_CSW				TPBulk_Block.TPBulk_CommandStatus
#define     CSW_wResidue			((INT16)TPBulk_CSW.dCSW_DataResidue)

BIT_EXT     BOTBF_StallAtBulkOut;
BIT_EXT     BOTBF_StallAtBulkIn;

// Xfer_Space
INT8_EXT BDATA_SEG Xfer_Space;
// Default Control Pipe Tansfer DCPXfer
BIT_EXT     DCPXfer_atMCUCODE;
BIT_EXT     DCPXfer_atMCURAM;
BIT_EXT     DCPXfer_atEEROM;
BIT_EXT     DCPXfer_atATA;
// Bulk Only Xfer space
BIT_EXT     BOTXfer_atRAM;
BIT_EXT     BOTXfer_atATA;
BIT_EXT     BOTXfer_atROM;

STRUC_EXT HW_ATA_DEVICES_EXTENSION	Hal4ATA_DevExt;
#define ATADevExt_IDData    Hal4ATA_DevExt.IdentifyData

BIT_EXT     ATABF_IsAttached;
BIT_EXT     ATABF_IsSupportMultiSector;
BIT_EXT     ATABF_IDEXfer_dir;
BIT_EXT     ATABF_IsSkipSetParameters;

INT8_EXT    Hal4ATA_SectCntInBlk;
/*
//*************************************************************************
//  Public temp var
//*************************************************************************
*/
STRUC_EXT   FLEXI_INT32 tempvars4UsbReq;
INT8_EXT BDATA_SEG FlexByte;
BIT_EXT     FlexByte_b0;
BIT_EXT     FlexByte_b1;
BIT_EXT     FlexByte_b2;
BIT_EXT     FlexByte_b3;
BIT_EXT     FlexByte_b4;
BIT_EXT     FlexByte_b5;
BIT_EXT     FlexByte_b6;
BIT_EXT     FlexByte_b7;

/*
//*************************************************************************
//  Private Data
//*************************************************************************
*/
code REQUEST_SENSE_DATA   Req_SenseData=
{
	//0x70, 0x00, 0x06, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x29,
    //0x00, 0x00, 0x00, 0x00, 0x00


     0x70, // INT8 ResponseCode : 7;
	 0,     //   INT8 Valid : 1;

	 0,//   INT8 SegmentNum;

	 0x5,//   INT8 SenseKey : 4; 5= illegal request
	 0,  // INT8 Reserved0 : 1;
	 0,//   INT8 WrongLenIndicator : 1;
	 0,//   INT8 EndofMedium : 1;
	 0,//   INT8 FileMark : 1;

	 0,//   INT8 Info_0;
	 0,//   INT8 Info_1;
	 0,//   INT8 Info_2;
	 0,//   INT8 Info_3;

	0xA,//    INT8 AdditionalSenseLen;

	0,//    INT8 CommandSpecInfo_0;
	0,//    INT8 CommandSpecInfo_1;
	0,//    INT8 CommandSpecInfo_2;
	0,//    INT8 CommandSpecInfo_3;

	0x29,//    INT8 ASC;
	0,//    INT8 ASCQ;
	0,//    INT8 FieldReplacableUnitCode;
	0,//    INT8 SenseKeySpec_0 : 7;
	0,//    INT8 SenseKeySpecValid : 1;
	0,//    INT8 SenseKeySpec_1;
	0 //    INT8 SenseKeySpec_2;

	};

RBC_PROPERTY                    RBC_PropertyData;



#define PARAMETER_LIST_LENGTH   (sizeof(MODE_PARAMETER_HEAD)+sizeof(MODE_PARAMETER_HEAD))


code MODE_PARAMETER_HEAD ParaHeadMask =
{
	PARAMETER_LIST_LENGTH-1,    /* mode data length*/
	0,                          /* medium type*/
	0,                          /* device spec Param*/
	0                           /* block Descriptor length*/
};

code MODE_RBC_DEVICE_PARAMETERS_PAGE ParaPageMask =
{
	MODE_PAGE_RBC_DEVICE_PARAMETERS,
	0,      /*Reserved*/
	0,      /*PageSavable*/

	0x00,   /*PageLength*/

	0,      /*WriteCacheDisable*/
	00,     /*Reserved*/

	{
		/*Logical block Size = 512 Bytes*/
		0x00,
		0x00
	},

	{
		/*Number of logical blocks*/
		0x00,
		0x00,
		0x00,
		0x00,
		0x00
	},

	0x00,   /*Power/Peformance*/

	0,      /*LockDisable*/
	0,      /*FormatDisable*/
	0,      /*WriteDisable*/
	0,      /*ReadDisable*/
	0x0,    /*Reserved*/

	0x00    /*Reserved*/
};

code MODE_PARAMETER_HEAD DefaultParaHead =
{
	PARAMETER_LIST_LENGTH-1,    /* mode data length*/
	0,                          /* medium type*/
	0,                          /* device spec Param*/
	0                           /* block Descriptor length*/
};

code MODE_RBC_DEVICE_PARAMETERS_PAGE DefaultParaPage =
{
	MODE_PAGE_RBC_DEVICE_PARAMETERS,
	0,      /*Reserved*/
	1,      /*PageSavable*/

	0x0B,   /*PageLength*/

	0,      /*WriteCacheDisable*/
	00,     /*Reserved*/

	{
		/*Logical block Size = 512 Bytes*/
		0x02,
		0x00
	},

	{
		/*Number of logical blocks*/
		0x00,
		0x00,
        0x00,
		0x00,
        0x00
    },

    0xFF,   /*Power/Peformance*/

    0,      /*LockDisable*/
    0,      /*FormatDisable*/
    0,      /*WriteDisable*/
    0,      /*ReadDisable*/
    0x0,    /*Reserved*/

	0x00    /*Reserved*/
};

code VPD_SERIAL_PAGE SerialPage =
{
	RBC_DEVICE,
	0x00,

    VPDPAGE_SERIAL_NUMBER,

    0x00,

    24,     //size of SerialNumber

    {
		// SerialNumber
    	'0',0,
	    '0',0,
	    '0',0,
	    '0',0,

    	'0',0,
	    '0',0,
	    '0',0,
	    '0',0,

    	'0',0,
    	'0',0,
	    '0',0,
	    '0',0
    }
};

code VPD_DEVICE_ID_PAGE DeviceIDPage =
{
	RBC_DEVICE,
    0x00,

    VPDPAGE_DEVICE_IDENTITY,

    0x00,

    sizeof(ASCII_ID_DESCRIPTOR),
    {
        0x02,
        0x00,

        0x01,
        0x00,
		0x00,

        0x00,

        sizeof(ASCII_ID_STRING),

		{
			// ASCII_ID_STRING
			'P','h','i','l',
            'i','p','s',' ',
            'S','u','p','e',
			'r',' ','D','i',
            's','k',' '
        }
    }
};

code STD_INQUIRYDATA inquiryData =
{
    0x00,// RBC_DEVICE,
    0,//INT8 Reserved0 : 3;

    0,//INT8 Reserved1 : 7;
    1,//INT8 RemovableMedia : 1;

    2,//INT8 Reserved2;

    2,//INT8 Reserved3 : 5;
    0,//INT8 NormACA : 1;
    0,//INT8 Obsolete0 : 1;
    0,//INT8 AERC : 1;

    //INT8 Reserved4[3];
    {
        0x1F,0,0
    },

    0,//INT8 SoftReset : 1;
    0,//INT8 CommandQueue : 1;
	0,//INT8 Reserved5 : 1;
	0,//INT8 LinkedCommands : 1;
	0,//INT8 Synchronous : 1;
	0,//INT8 Wide16Bit : 1;
	0,//INT8 Wide32Bit : 1;
	0,//INT8 RelativeAddressing : 1;

    //INT8 VendorId[8];
    {
        'P','H','I','L',
        'I','P','S',' '
    },

	//INT8 ProductId[16];
    {
        'U','S','B','-',
    	'I','D','E',' ',
    	'A','d','a','p',
    	't','e','r',' '
    },

	//INT8 ProductRevisionLevel[4];
    {
        '0','.','0','0'
    },


//  Above is 36 bytes
//  can be tranmitted by Bulk



    //INT8 VendorSpecific[20]; out[64 bytes] within one packet only.
    {
        0, 0, 0, 0,
        0, 0, 0, 0,
        0, 0, 0, 0,
        0, 0, 0, 0,
        0, 0, 0, 0
    },


    0,//INT8 InfoUnitSupport : 1;
    0,//INT8 QuickArbitSupport : 1;
    0,//INT8 Clocking : 2;
    0,//INT8 Reserved1 : 4;
    0,//INT8  Reserved2 ;

    //USHORT VersionDescriptor[8] ;
    {
        0, 0, 0, 0,
        0, 0, 0, 0
    },


    //INT8 Reserved3[22];
    {
        0, 0, 0, 0,
        0, 0, 0, 0,
        0, 0, 0, 0,
        0, 0, 0, 0,
        0, 0, 0, 0,
        0, 0
    }

};


/*
//*************************************************************************
//  Subroutines
//*************************************************************************
*/

BOOLEAN RBC_Handler( void )
{

#define cdbGeneric RBC_CDB.RbcCdb_Generic
    BOOLEAN retStatus = FALSE;

	BOTXfer_wResidue = 0;

	switch(cdbGeneric.OperationCode)
	{
		/* required command */
		case RBC_CMD_READ10:
			retStatus = RBC_Read();
			break;
		case RBC_CMD_READCAPACITY:
			retStatus = RBC_ReadCapacity();
			break;
		case RBC_CMD_STARTSTOPUNIT:
			retStatus = RBC_OnOffUnit();
			break;
        case RBC_CMD_SYNCCACHE:
            retStatus = RBC_SyncCache();
			break;
        case RBC_CMD_VERIFY10:
            retStatus = RBC_Verify();
            break;
        case RBC_CMD_WRITE10:
            retStatus = RBC_Write();
            break;
        case SPC_CMD_INQUIRY:
            retStatus = SPC_Inquiry();
            break;
        case SPC_CMD_MODESELECT6://0x15
            retStatus = SPC_ModeSelect();
            break;
        case SPC_CMD_MODESENSE6:
            retStatus = SPC_ModeSense();//0x1A
            break;
		case SPC_CMD_PRVENTALLOWMEDIUMREMOVAL:
			retStatus = SPC_LockMedia();
            break;
        case SPC_CMD_TESTUNITREADY: //0x00
            retStatus = SPC_TestUnit();
            break;
        case SPC_CMD_REQUESTSENSE: //0x03
            retStatus = SPC_RequestSense();
            break;
		/* optional commands */
		case RBC_CMD_FORMAT:
			retStatus = RBC_Format();
			break;
		case SPC_CMD_RESERVE6:
			retStatus = SPC_Reserve6();
			break;
		case SPC_CMD_RELEASE6:
			retStatus = SPC_Release6();
			break;
		case SPC_CMD_PERSISTANTRESERVIN:
			retStatus = SPC_PersisReserveIn();
			break;
		case SPC_CMD_PERSISTANTRESERVOUT:
			retStatus = SPC_PersisReserveOut();
			break;
		case SPC_CMD_WRITEBUFFER:
			retStatus = SPC_WriteBuff();
			break;
		case SPC_CMD_READLONG:
			retStatus = SPC_READLONG();//0x23
			break;
		default:
			// Invalid CBW
			TPBulksup_ErrorHandler(CASECBW,0);
			//SCSI_SENSE_ILLEGAL_REQUEST=0x05
			//SCSI_ADSENSE_ILLEGAL_COMMAND=0x20
			RBC_BuildSenseData(SCSI_SENSE_ILLEGAL_REQUEST,SCSI_ADSENSE_ILLEGAL_COMMAND,0);
			TPBulk_CSWHandler();// Goto USBFSM4BOT_CSWPROC;
			break;
	}

	return retStatus;
#undef cdbGeneric
}


/*
////////////////////////////////////////////////////////////////////////////////////
// Reduced Block Command Support
////////////////////////////////////////////////////////////////////////////////////
*/

BOOLEAN SPC_READLONG(void)
{
		BOTXfer_wResidue = CBW_wXferLen;
		TPBulksup_ErrorHandler(CASECMDFAIL,BOTXfer_wResidue);
		RBC_BuildSenseData(SCSI_SENSE_ILLEGAL_REQUEST,SCSI_ADSENSE_INVALID_CDB,0);

		TPBulk_CSWHandler();// Goto USBFSM4BOT_CSWPROC;
}



BOOLEAN RBC_Read(void)
{

#define cdbRead RBC_CDB.RbcCdb_Read

    Hal4ATA_SectCntInBlk = ATADevExt_IDData.MaximumBlockTransfer << BITNUM4EP2PKT_PER_SECTOR;
	/*
	// Setting ATA Hardware
	*/
    ATABF_IDEXfer_dir = 1;
	Hal4ATA_ReadWriteSetting();

	/*
	// config TPBulkXfer Paras
	*/
    Xfer_Space &= BOTXFERSPACE_MASK;
    BOTXfer_atATA = 1;
    BOTXfer_wResidue = CBW_wXferLen;

	TPBulksup_ErrorHandler(CASE6,BOTXfer_wResidue);
	RBC_BuildSenseData(SCSI_SENSE_NO_SENSE,0,0);

	BOTFSMstate = USBFSM4BOT_DATAIN;

	return (TRUE);

#undef cdbRead
}

/*

BOOLEAN RBC_Read(void)
{
char temp, temp1;
unsigned int a ;
unsigned int i;
int b;

#define cdbRead RBC_CDB.RbcCdb_Read


    Hal4ATA_SectCntInBlk = ATADevExt_IDData.MaximumBlockTransfer << BITNUM4EP2PKT_PER_SECTOR;
	/*
	// Setting ATA Hardware
	*/
/*
    ATABF_IDEXfer_dir = 1;

    while(TRUE)
	{
	//Hal4ATA_ReadWriteSetting();
	for (b=0; b!=20;b++)
	{
	Hal4Sys_ATAPortOutB(0x52,0);
	Hal4Sys_ATAPortOutB(0x53,b);
	Hal4Sys_ATAPortOutB(0x54,0);
	Hal4Sys_ATAPortOutB(0x55,0);
	Hal4Sys_ATAPortOutB(0x56,0);

	Hal4Sys_ATAPortOutB(0x57, IDE_COMMAND_READ);

	P1 = 0xD0;

	for (a=512 ; a!=0 ; a--)
	{
    ATA_RD_N = 0;
    temp = P0;
    temp1=P2;
    ATA_RD_N = 1;
    P0 = 0xFF;
	}
	}
}
	/*
	// config TPBulkXfer Paras
	*/
    /*
    Xfer_Space &= BOTXFERSPACE_MASK;
    BOTXfer_atATA = 1;
    BOTXfer_wResidue = CBW_wXferLen;

	TPBulksup_ErrorHandler(CASE6,BOTXfer_wResidue);
	RBC_BuildSenseData(SCSI_SENSE_NO_SENSE,0,0);

	BOTFSMstate = USBFSM4BOT_DATAIN;

	return (TRUE);

#undef cdbRead
}

*/

BOOLEAN RBC_Write(void)
{
#define cdbWrite    RBC_CDB.RbcCdb_Write

    Hal4ATA_SectCntInBlk = ATADevExt_IDData.MaximumBlockTransfer << BITNUM4EP2PKT_PER_SECTOR;
	/*
	// Setting ATA Hardware
	*/
    ATABF_IDEXfer_dir = 0;
	Hal4ATA_ReadWriteSetting();

	/*
	// Config TPBulkXfer Paras
	*/
    Xfer_Space &= BOTXFERSPACE_MASK;
    BOTXfer_atATA = 1;
    BOTXfer_wResidue = CBW_wXferLen;

	TPBulksup_ErrorHandler(CASE12,BOTXfer_wResidue);
	RBC_BuildSenseData(SCSI_SENSE_NO_SENSE,0,0);

	BOTFSMstate = USBFSM4BOT_DATAOUT;

	return (TRUE);

#undef cdbWrite
}

BOOLEAN RBC_ReadCapacity(void)
{
#define cdbReadCap RBC_CDB.RbcCdb_ReadCapacity

	/*
	// Calculate last sector.
	*/
	cdbReadCap.tmpVar.l[1] =  ((INT32)ATADevExt_IDData.CurrentSectorCapacity.u0) - 1;

// 32bits info
//ATADevExt_IDData.CurrentSectorCapacity.ints.i0 = Hal4Sys_ATADataPortInW()
//ATADevExt_IDData.CurrentSectorCapacity.ints.i1 = Hal4Sys_ATADataPortInW()
/* struct
    {
        INT8 c3;  // MSB for 8051 Keil C
        INT8 c2;
        INT8 c1;
        INT8 c0;   // LSB for 8051 Keil C
    } chars0;
*/
	/* store it in big endian */
	cdbReadCap.tmpVar.CapData.LBA_3 = ( INT8 ) cdbReadCap.tmpVar.l0[1].chars0.c3;
	cdbReadCap.tmpVar.CapData.LBA_2 = ( INT8 ) cdbReadCap.tmpVar.l0[1].chars0.c2;
	cdbReadCap.tmpVar.CapData.LBA_1 = ( INT8 ) cdbReadCap.tmpVar.l0[1].chars0.c1;
	cdbReadCap.tmpVar.CapData.LBA_0 = ( INT8 ) cdbReadCap.tmpVar.l0[1].chars0.c0;

	/*
	// Bytes Per Block is 512Bytes
	// 00020000 is 0x200 in big endian
	*/
	cdbReadCap.tmpVar.CapData.BlockLen_3 = 0;
	cdbReadCap.tmpVar.CapData.BlockLen_2 = 0;
	cdbReadCap.tmpVar.CapData.BlockLen_1 = 0x02;
	cdbReadCap.tmpVar.CapData.BlockLen_0 = 0;
	/*
	// Adjust TPBulkXfer Paras
	*/
    Xfer_Space &= BOTXFERSPACE_MASK;
    BOTXfer_atRAM = 1;

	BOTXfer_wResidue = sizeof(READ_CAPACITY_DATA);
	BOTXfer_pData = (PINT8)&(cdbReadCap.tmpVar);

	TPBulksup_ErrorHandler(CASE6, BOTXfer_wResidue);
	RBC_BuildSenseData(SCSI_SENSE_NO_SENSE,0,0);

	BOTFSMstate = USBFSM4BOT_DATAIN;

	return(TRUE);
#undef cdbReadCap
}

BOOLEAN RBC_OnOffUnit(void)
{
#define cdbOnOffUnit RBC_CDB.RbcCdb_OnOffUnit

	//BOTXfer_wResidue = 0;

	switch(cdbOnOffUnit.Flags.bits1.PowerConditions)
	{
	case PWR_NOCHANGE:
		switch(cdbOnOffUnit.Flags.bits1.MediumState)
		{
		case MEDIUM_LOAD:
			break;
		case MEDIUM_UNLOAD:
			break;
		case MEDIUM_STOP:
			break;
		case MEDIUM_READY:
			break;
		}
		break;
	case PWR_ACTIVE:
		break;
	case PWR_IDLE:
		break;
	case PWR_STANDBY:
		break;
	case PWR_SLEEP:
		break;
	case PWR_DEVCTRL:
	default:
		break;
	}


	RBC_PropertyData.bits.MediumState = cdbOnOffUnit.Flags.bits1.MediumState;
	RBC_PropertyData.bits.PowerState = cdbOnOffUnit.Flags.bits1.PowerConditions;

	TPBulksup_ErrorHandler(CASE1,0);
	RBC_BuildSenseData(SCSI_SENSE_NO_SENSE,0,0);

    TPBulk_CSWHandler();// Goto USBFSM4BOT_CSWPROC;

	return TRUE;
#undef cdbOnOffUnit
}

BOOLEAN RBC_SyncCache(void)
{
#define cdbSyncRBC RBC_CDB.RbcCdb_SyncCache

	//BOTXfer_wResidue = 0;
	TPBulksup_ErrorHandler(CASE1,0);
	RBC_BuildSenseData(SCSI_SENSE_NO_SENSE,0,0);

    TPBulk_CSWHandler();// Goto USBFSM4BOT_CSWPROC;
	return TRUE;
#undef cdbSyncRBC
}


BOOLEAN  RBC_Verify(void)
{
#define cdbVerifyRBC RBC_CDB.RbcCdb_Verify

	if( CBW_wXferLen == 0 )
	{
		//BOTXfer_wResidue = 0;
		TPBulksup_ErrorHandler(CASE1,0);
		RBC_BuildSenseData(SCSI_SENSE_NO_SENSE,0,0);
	    TPBulk_CSWHandler();// Goto USBFSM4BOT_CSWPROC;
	}
	else
	{
		/*
		// Config TPBulkXfer Paras
		*/
		Xfer_Space &= BOTXFERSPACE_MASK;
		BOTXfer_atROM = 1;
		BOTXfer_wResidue = CBW_wXferLen;

		TPBulksup_ErrorHandler(CASE12,BOTXfer_wResidue);
		RBC_BuildSenseData(SCSI_SENSE_NO_SENSE,0,0);

		BOTFSMstate = USBFSM4BOT_DATAOUT;
	}
	return TRUE;
#undef cdbVerifyRBC
}


/*
////////////////////////////////////////////////////////////////////////////////////
// SCSI Primary Command Support
////////////////////////////////////////////////////////////////////////////////////
*/

BOOLEAN SPC_Inquiry(void)
{
#define cdbInquirySPC RBC_CDB.SpcCdb_Inquiry
	BOOLEAN		retStatus = FALSE;


	if(cdbInquirySPC.EnableVPD)
	{
		switch(cdbInquirySPC.PageCode)
		{
		case VPDPAGE_SERIAL_NUMBER:

			BOTXfer_pData =(PINT8) &SerialPage;
			BOTXfer_wResidue = sizeof(VPD_SERIAL_PAGE);
			break;

		case VPDPAGE_DEVICE_IDENTITY:

			retStatus = TRUE;
			BOTXfer_pData = (PINT8)&DeviceIDPage;
			BOTXfer_wResidue = sizeof(VPD_DEVICE_ID_PAGE);
			break;

		default:
			//retStatus = FALSE;
			TPBulksup_ErrorHandler(CASECMDFAIL,BOTXfer_wResidue);
			RBC_BuildSenseData(SCSI_SENSE_ILLEGAL_REQUEST,SCSI_ADSENSE_ILLEGAL_COMMAND,0x00);

			TPBulk_CSWHandler();// Goto USBFSM4BOT_CSWPROC;
			return retStatus;
		}
	}
	else if(cdbInquirySPC.CmdSupportData)
	{
		//retStatus = FALSE;
		TPBulksup_ErrorHandler(CASECMDFAIL,BOTXfer_wResidue);
		RBC_BuildSenseData(SCSI_SENSE_ILLEGAL_REQUEST,SCSI_ADSENSE_ILLEGAL_COMMAND,0x00);

		TPBulk_CSWHandler();// Goto USBFSM4BOT_CSWPROC;
		return retStatus;
	}
	else
	{

        BOTXfer_pData =(PINT8) &inquiryData;
		BOTXfer_wResidue = sizeof(STD_INQUIRYDATA);
	}

	retStatus = TRUE;
    Xfer_Space &= BOTXFERSPACE_MASK;
    BOTXfer_atROM = 1;

	if( BOTXfer_wResidue > CBW_wXferLen )
	{
		BOTXfer_wResidue = CBW_wXferLen;
		TPBulksup_ErrorHandler(CASE6,BOTXfer_wResidue);
		RBC_BuildSenseData(SCSI_SENSE_NO_SENSE,0,0);
	}
	else if ( BOTXfer_wResidue == CBW_wXferLen )
	{
		TPBulksup_ErrorHandler(CASE6,BOTXfer_wResidue);
		RBC_BuildSenseData(SCSI_SENSE_NO_SENSE,0,0);
	}
	else
	{
		TPBulksup_ErrorHandler(CASE5,BOTXfer_wResidue);
		RBC_BuildSenseData(SCSI_SENSE_NO_SENSE,0,0);
	}

	BOTFSMstate = USBFSM4BOT_DATAIN;// Goto USBFSM4BOT_DATAIN

	return retStatus;
#undef cdbInquirySPC
}

BOOLEAN SPC_ModeSelect(void)
{
#define cdbModeSelectSPC    RBC_CDB.SpcCdb_ModeSelect
	BOOLEAN retStatus = FALSE;

	//
	//Just Retrieve and discard data from USB FIFO

    Xfer_Space &= BOTXFERSPACE_MASK;
    BOTXfer_atROM = 1;

    BOTXfer_pData = (PINT8)0;
	BOTXfer_wResidue = cdbModeSelectSPC.ParameterLen;

	if(cdbModeSelectSPC.SavePage != 1)
	{
		if(CBW_wXferLen < BOTXfer_wResidue)
		{
			BOTXfer_wResidue = CBW_wXferLen;
			TPBulksup_ErrorHandler(CASE13,BOTXfer_wResidue);
			RBC_BuildSenseData(SCSI_SENSE_ILLEGAL_REQUEST,SCSI_ADSENSE_INVALID_PARAMETER,0);

			//retStatus = FALSE;
			TPBulk_CSWHandler();// Goto USBFSM4BOT_CSWPROC;
			return retStatus;
		}
		else if(CBW_wXferLen == BOTXfer_wResidue)
		{
			TPBulksup_ErrorHandler(CASE12,BOTXfer_wResidue);
			RBC_BuildSenseData(SCSI_SENSE_NO_SENSE,0,0);
			retStatus = TRUE;
		}
		else
		{
			TPBulksup_ErrorHandler(CASE11,BOTXfer_wResidue);
			RBC_BuildSenseData(SCSI_SENSE_NO_SENSE,0,0);
			retStatus = TRUE;
		}

		BOTFSMstate = USBFSM4BOT_DATAOUT;
	}
	else
	{
		BOTXfer_wResidue = CBW_wXferLen;
		TPBulksup_ErrorHandler(CASECMDFAIL,BOTXfer_wResidue);
		RBC_BuildSenseData(SCSI_SENSE_ILLEGAL_REQUEST,SCSI_ADSENSE_INVALID_CDB,0);

		//retStatus = FALSE;
		TPBulk_CSWHandler();// Goto USBFSM4BOT_CSWPROC;
	}

	return retStatus;

#undef cdbModeSelectSPC
}

BOOLEAN SPC_ModeSense(void)
{
#define cdbModeSenseSPC RBC_CDB.SpcCdb_ModeSense
	BOOLEAN retStatus = FALSE;

	if(cdbModeSenseSPC.PageCode == MODE_PAGE_RBC_DEVICE_PARAMETERS )
	{
		switch(cdbModeSenseSPC.PageControl)
		{
		case PAGECTRL_CHANGEABLE:

			BOTXfer_pData =(PINT8) &ParaHeadMask;
			BOTXfer_wResidue = sizeof(PARAMETER_LIST_LENGTH);
			break;

		case PAGECTRL_DEFAULT:
		case PAGECTRL_CURRENT:

			BOTXfer_pData =(PINT8) &DefaultParaHead;
			BOTXfer_wResidue = sizeof(PARAMETER_LIST_LENGTH);
			break;

		case PAGECTRL_SAVED:
		default:
			//retStatus = FALSE;
			TPBulksup_ErrorHandler(CASECMDFAIL,BOTXfer_wResidue);
			RBC_BuildSenseData(SCSI_SENSE_ILLEGAL_REQUEST,SCSI_ADSENSE_SAVE_ERROR,0);
			TPBulk_CSWHandler();// Goto USBFSM4BOT_CSWPROC;
			break;
		}

		if(CBW_wXferLen < BOTXfer_wResidue)
		{
			BOTXfer_wResidue = CBW_wXferLen;
			TPBulksup_ErrorHandler(CASE6,BOTXfer_wResidue);
			RBC_BuildSenseData(SCSI_SENSE_NO_SENSE,0,0);
		}
		else if(CBW_wXferLen == BOTXfer_wResidue)
		{
			TPBulksup_ErrorHandler(CASE6,BOTXfer_wResidue);
			RBC_BuildSenseData(SCSI_SENSE_NO_SENSE,0,0);
		}
		else
		{
			TPBulksup_ErrorHandler(CASE5,BOTXfer_wResidue);
			RBC_BuildSenseData(SCSI_SENSE_NO_SENSE,0,0);
		}

		retStatus = TRUE;
		BOTFSMstate = USBFSM4BOT_DATAIN;// Goto USBFSM4BOT_DATAIN
	}
	else
	{
		//retStatus = FALSE;
		TPBulksup_ErrorHandler(CASECMDFAIL,BOTXfer_wResidue);
		RBC_BuildSenseData(SCSI_SENSE_ILLEGAL_REQUEST,SCSI_ADSENSE_INVALID_CDB,0);
		TPBulk_CSWHandler();// Goto USBFSM4BOT_CSWPROC;
	}

	return retStatus;
#undef cdbModeSenseSPC
}

BOOLEAN SPC_LockMedia(void)
{
#define cdbLockSPC RBC_CDB.SpcCdb_Remove


	RBC_PropertyData.bits.MediumRemovFlag = cdbLockSPC.Prevent;

	if (RBC_PropertyData.bits.MediumRemovFlag == 01)
		IDE_CS = 0;
		else
		IDE_CS = 1;
	TPBulksup_ErrorHandler(CASE1,0);
	RBC_BuildSenseData(SCSI_SENSE_NO_SENSE,0,0);
	TPBulk_CSWHandler();// Goto USBFSM4BOT_CSWPROC;
	return TRUE;

#undef cdbLockSPC
}

BOOLEAN SPC_TestUnit(void)
{
#define cdbTestUnit RBC_CDB.SpcCdb_TestUnit


	if( ATABF_IsAttached )
	{
		TPBulksup_ErrorHandler(CASE1,0);
		RBC_BuildSenseData(SCSI_SENSE_NO_SENSE,0,0);
	}
	else
	{
		TPBulksup_ErrorHandler(CASECMDFAIL,0);
		RBC_BuildSenseData(SCSI_SENSE_NOT_READY,SCSI_ADSENSE_NO_MEDIA_IN_DEVICE,0);
	}

	TPBulk_CSWHandler();// Goto USBFSM4BOT_CSWPROC;
	return TRUE;

#undef cdbTestUnit
}

BOOLEAN SPC_RequestSense(void)
{
#define cdbRequestSenseSPC RBC_CDB.SpcCdb_RequestSense

	/*
	// Adjust TPBulkXfer Paras
	*/

    Xfer_Space &= BOTXFERSPACE_MASK;
  //  BOTXfer_atRAM = 1;
      BOTXfer_atROM = 1;

	BOTXfer_pData =(PINT8)&Req_SenseData ;
	BOTXfer_wResidue = sizeof(Req_SenseData);

	TPBulksup_ErrorHandler(CASE6,BOTXfer_wResidue);

	BOTFSMstate = USBFSM4BOT_DATAIN;

	return TRUE;
#undef cdbRequestSenseSPC
}

//Optional
BOOLEAN RBC_Format(void)
{
	TPBulksup_ErrorHandler(CASECMDFAIL,0);
	RBC_BuildSenseData(SCSI_SENSE_MEDIUM_ERROR,SCSI_ADSENSE_FORMAT_ERROR,0x01);
	TPBulk_CSWHandler();// Goto USBFSM4BOT_CSWPROC;
	return TRUE;

}

BOOLEAN SPC_Reserve6(void)
{
	TPBulksup_ErrorHandler(CASECMDFAIL,0);
	RBC_BuildSenseData(SCSI_SENSE_ILLEGAL_REQUEST,SCSI_ADSENSE_ILLEGAL_COMMAND,0);
	TPBulk_CSWHandler();// Goto USBFSM4BOT_CSWPROC;
	return TRUE;
}

BOOLEAN SPC_Release6(void)
{
	TPBulksup_ErrorHandler(CASECMDFAIL,0);
	RBC_BuildSenseData(SCSI_SENSE_ILLEGAL_REQUEST,SCSI_ADSENSE_ILLEGAL_COMMAND,0);
	TPBulk_CSWHandler();// Goto USBFSM4BOT_CSWPROC;
	return TRUE;
}

BOOLEAN SPC_PersisReserveIn(void)
{
	TPBulksup_ErrorHandler(CASECMDFAIL,0);
	RBC_BuildSenseData(SCSI_SENSE_ILLEGAL_REQUEST,SCSI_ADSENSE_ILLEGAL_COMMAND,0);
	TPBulk_CSWHandler();// Goto USBFSM4BOT_CSWPROC;
	return TRUE;

}

BOOLEAN SPC_PersisReserveOut(void)
{

	//Just Retrieve and discard data from USB FIFO

    Xfer_Space &= BOTXFERSPACE_MASK;
    BOTXfer_atROM = 1;

    BOTXfer_pData = (PINT8)0;
	BOTXfer_wResidue = CBW_wXferLen;

	TPBulksup_ErrorHandler(CASECMDFAIL,BOTXfer_wResidue);
	RBC_BuildSenseData(SCSI_SENSE_ILLEGAL_REQUEST,SCSI_ADSENSE_ILLEGAL_COMMAND,0);

	BOTFSMstate = USBFSM4BOT_DATAOUT;

	return TRUE;
}

BOOLEAN SPC_WriteBuff(void)
{
#define cdbWriteBuff RBC_CDB.SpcCdb_WriteBuffer

	//Just Retrieve and discard data from USB FIFO

    Xfer_Space &= BOTXFERSPACE_MASK;
    BOTXfer_atROM = 1;

    BOTXfer_pData = (PINT8)0;
	BOTXfer_wResidue = CBW_wXferLen;

	TPBulksup_ErrorHandler(CASECMDFAIL,BOTXfer_wResidue);
	RBC_BuildSenseData(SCSI_SENSE_ILLEGAL_REQUEST,SCSI_ADSENSE_CMDSEQ_ERROR,0);

	BOTFSMstate = USBFSM4BOT_DATAOUT;

	return TRUE;
#undef cdbWriteBuff
}



void RBC_BuildSenseData(INT8 SenseKey, INT8 ASC, INT8 ASCQ)
{

/*
	RBC_SenseData.ResponseCode = SCSI_RESPONSECODE_CURRENT_ERROR;
	RBC_SenseData.Valid = 0;
	//RBC_SenseData.SegmentNum = 0;
	RBC_SenseData.SenseKey =  SenseKey;
	//RBC_SenseData.Reserved0 = 0;
	//RBC_SenseData.WrongLenIndicator = 0;
	//RBC_SenseData.EndofMedium = 0;
	//RBC_SenseData.FileMark = 0;
	//RBC_SenseData.Info_0 = 0;
	//RBC_SenseData.Info_1 = 0;
	//RBC_SenseData.Info_2 = 0;
	//RBC_SenseData.Info_3 = 0;
	RBC_SenseData.AdditionalSenseLen = 0xa;
	//RBC_SenseData.CommandSpecInfo_0 = 0;
	//RBC_SenseData.CommandSpecInfo_1 = 0;
	//RBC_SenseData.CommandSpecInfo_2 = 0;
	//RBC_SenseData.CommandSpecInfo_3 = 0;
	RBC_SenseData.ASC = ASC;
	RBC_SenseData.ASCQ = ASCQ;
	//RBC_SenseData.FieldReplacableUnitCode = 0;
	//RBC_SenseData.SenseKeySpec_0 = 0;
	//RBC_SenseData.SenseKeySpecValid = 0;
	//RBC_SenseData.SenseKeySpec_1 = 0;
	//RBC_SenseData.SenseKeySpec_2 = 0;
*/
}