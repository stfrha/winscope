#include <reg51.h>
#define		UC			unsigned char
#define		UI			unsigned int
#define		US			unsigned short
#define		UL			unsigned long
#define		ULI			unsigned long int

//Hardware Mapping
//================
#define LED 		P31
#define ATA_IoRdy  	P33
#define ATA_RESET_N	P34
#define D12_INT_N   P32


//Register Mapping
//================

UC	xdata	D12_COMMAND _at_ 0x4001;	//Single Byte
UC  xdata   D12_DATA    _at_ 0x4000;	//Single Byte
UI  xdata   IDE_WR_1F0  _at_ 0x8000;	//2 bytes
									//Eg, IDE_WR_1F0 = 0x0506;
									//*(0x8000) = 0x05;
									//*(0x8001) = 0x06;

UI  xdata   IDE_RD_1F0  _at_ 0x8002;	//2 bytes
									//Eg, IDE_WR_1F0 = 0x0506;
									//*(0x8000) = 0x05;
									//*(0x8001) = 0x06;
UC  xdata   IDE_1F1 	_at_ 0x8004; //Single Byte
UC  xdata   IDE_1F2 	_at_ 0x8005; //Single Byte
UC  xdata   IDE_1F3 	_at_ 0x8006; //Single Byte
UC  xdata   IDE_1F4 	_at_ 0x8007; //Single Byte
UC  xdata   IDE_1F5 	_at_ 0x8008; //Single Byte
UC  xdata   IDE_1F6 	_at_ 0x8009; //Single Byte
UC  xdata   IDE_1F7 	_at_ 0x800a; //Single Byte
UC  xdata   IDE_3F6 	_at_ 0x800b; //Single Byte
UC  xdata   IDE_3F7 	_at_ 0x800c; //Single Byte


void main(void)
{
  PCON = 0x40; //Put SMOD = 1;

	LED = 1;
	ATA_IoRdy = 1;
	ATA_RESET_N = 1;
	D12_INT_N = 1;


/*
//Testing the ATA interfacing

  while (1)
  {
	IDE_WR_1F0 = 0x0000;
	IDE_WR_1F0 = 0x0001;
	IDE_WR_1F0 = 0x0004;
	IDE_WR_1F0 = 0x0008;

	IDE_WR_1F0 = 0x0010;
	IDE_WR_1F0 = 0x0040;
	IDE_WR_1F0 = 0x0080;

	IDE_WR_1F0 = 0x0100;
	IDE_WR_1F0 = 0x0400;
	IDE_WR_1F0 = 0x0800;

	IDE_WR_1F0 = 0x1000;
	IDE_WR_1F0 = 0x4000;
	IDE_WR_1F0 = 0x8000;

	tempI = IDE_RD_1F0;
	IDE_1F1 = 0X55;
	tempC = IDE_1F1;
	for (i = 0; i < 256; i++)
	 for (j = 0; j < 200; j++);
	LED = !LED;
  }

*/

/*
//Testing the D12 interfacing

  D12_COMMAND = 0xf3;
  D12_DATA = 0xff;
  while (1)
  {
	for (i = 0; i < 256; i++)
	 for (j = 0; j < 200; j++);
	LED = !LED;
  }
*/

}
