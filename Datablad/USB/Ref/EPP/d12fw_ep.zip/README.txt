----------------------------------------------------------
To build generic firmware for D12 USB-EPP Evaluation Kit
----------------------------------------------------------
Compiler: Keil C Compiler for 8031
Execute: GEN.BAT
Files Used: 
	MainLoop.c, MainLoop.h
	Isr.c
	D12CI.c, D12CI.h
	Chap_9.c, Chap_9.h
	EPPHAL.c, EPPHAL.h
	ProtoDMA.c, ProtoDMA.h

	GEN.BAT, Generic.lin
Code Generated: Generic.hex



---------------------------------------------------------
To build TWAIN firmware for D12 USB-EPP Evaluation Kit
---------------------------------------------------------
Compiler: Keil C Compiler for 8031
Execute: TWAIN.BAT
Files Used: 
	MainLoop.c, MainLoop.h
	Isr.c
	D12CI.c, D12CI.h
	Chap_9.c, Chap_9.h
	EPPHAL.c, EPPHAL.h
	TWAIN.c, ProtoDMA.h

	TWAIN.BAT, TWAIN.lin
Code Generated: TWAIN.hex


---------------------------------------------------------
To build firmware for D12 PC Evaluation Kit
---------------------------------------------------------
Compiler: Turbo C++ 3.0 or above
Project File: D12FW.PRJ
Files Used: 
	MainLoop.c, MainLoop.h
	Isr.c
	D12CI.c, D12CI.h
	Chap_9.c, Chap_9.h
	ProtoDMA.c, ProtoDMA.h
	ISA_DMA.c

	D12FW.PRJ
Exe Generated: D12FW.EXE


