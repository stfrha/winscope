/*
   //*************************************************************************
   //
   //                  P H I L I P S   P R O P R I E T A R Y
   //
   //           COPYRIGHT (c)   1997 BY PHILIPS SINGAPORE.
   //                     --  ALL RIGHTS RESERVED  --
   //
   // File Name:	TWAIN.C
   // Author:		Wenkai Du
   // Created:		18 Aug 98
   // Modified:
   // Revision:		1.0
   //
   //*************************************************************************
*/

#include <stdio.h>
#include <string.h>

#ifdef __C51__
	#include <reg51.h>                /* special function register declarations   */
#else
	#include <dos.h>
#endif

#include "epphal.h"
#include "d12ci.h"
#include "mainloop.h"
#include "usb100.h"
#include "chap_9.h"

extern CONTROL_XFER ControlData;
extern IO_REQUEST idata ioRequest;
extern EPPFLAGS bEPPflags;

unsigned char idata TwainFileNumber = 0, idata TwainCurrentFile = 0;
unsigned long idata TwainFileSize;

void get_firmware_version()
{
	unsigned char i;

#ifndef __C51__
	i = 0x01; // firmware version number, return 0x01 for PC kit version 1
#else
	i = 0x21; // firmware version number, return 0x11 for PC kit using 8052, 0x21 for USB-EPP
#endif
	single_transmit((unsigned char *)&i, 1);
}

void get_twain_request()
{
	if(ControlData.DeviceRequest.wValue == 0 &&
		ControlData.DeviceRequest.wLength == 1) // get file number
		single_transmit((unsigned char *)&TwainFileNumber, 1);
	if(ControlData.DeviceRequest.wValue == 1 &&
		ControlData.DeviceRequest.wLength == 1) // get current file
		single_transmit((unsigned char *)&TwainCurrentFile, 1);
	else if(ControlData.DeviceRequest.wValue == 2 &&
		ControlData.DeviceRequest.wLength == 4) // get file size
		single_transmit((unsigned char *)&TwainFileSize, 4);
	else
		stall_ep0();
}

void set_twain_request()
{
	if(ControlData.DeviceRequest.wValue == 1 &&
		ControlData.DeviceRequest.wLength == 1) {// set current file
		TwainCurrentFile = ControlData.dataBuffer[0];
		single_transmit(0, 0);
	}
	else if(ControlData.DeviceRequest.wValue == 2 &&
		ControlData.DeviceRequest.wLength == 4) { // set file size
		memcpy((unsigned char *)&TwainFileSize,
			ControlData.dataBuffer,
			ControlData.DeviceRequest.wLength);
		TwainFileNumber = 1;
		single_transmit(0, 0);
	}
	else if(ControlData.DeviceRequest.wValue == 6 &&
		ControlData.DeviceRequest.wLength == 1) { // clear all
		TwainFileNumber = 0;
		single_transmit(0, 0);
	}
	else
		stall_ep0();
}

void setup_dma_request()
{
#ifndef __C51__
	unsigned long offset;
#else
	unsigned char offset;
#endif

	memcpy((unsigned char *)&ioRequest + ControlData.DeviceRequest.wValue,
		ControlData.dataBuffer,
		ControlData.DeviceRequest.wLength);

	ioRequest.uSize = SWAP(ioRequest.uSize);
	ioRequest.uAddressL = SWAP(ioRequest.uAddressL);

	if(ioRequest.uSize > DMA_BUFFER_SIZE) { // Unaccepted request
		stall_ep0();
	}
	else {

		if(bEPPflags.bits.dma_state == DMA_IDLE) {
			DISABLE;
			bEPPflags.bits.setup_dma = 1;
			ENABLE;
		}
		else {
			DISABLE;
			bEPPflags.bits.dma_state = DMA_PENDING;
			ENABLE;
		}

	} // else if accepted request
}

void read_write_register(void)
{
	unsigned char i;

	if(ControlData.DeviceRequest.bmRequestType & (unsigned char)USB_ENDPOINT_DIRECTION_MASK) {

		if(bEPPflags.bits.verbose)
			printf("Read Registers: Offset = 0x%x, Length = 0x%x, Index = 0x%x.\n",
				ControlData.DeviceRequest.wValue,
				ControlData.DeviceRequest.wLength,
				ControlData.DeviceRequest.wIndex);

		if(ControlData.DeviceRequest.wIndex == GET_FIRMWARE_VERSION &&
			ControlData.DeviceRequest.wValue == 0 &&
			ControlData.DeviceRequest.wLength == 1)
			get_firmware_version();
		else if(ControlData.DeviceRequest.wIndex == GET_SET_TWAIN_REQUEST)
			get_twain_request();
		else
			stall_ep0();

	}	// if read register
	else{
		if(bEPPflags.bits.verbose) {

			printf("Write Registers: Offset = 0x%x, Length = 0x%x, Index = 0x%x.\n",
				ControlData.DeviceRequest.wValue,
				ControlData.DeviceRequest.wLength,
				ControlData.DeviceRequest.wIndex);

			printf("Data: ");
			for(i = 0; i < ControlData.DeviceRequest.wLength; i ++)
#ifndef __C51__
				printf("0x%x, ", *((ControlData.dataBuffer)+i));
#else
				printf("0x%bx, ", *((ControlData.dataBuffer)+i));
#endif
			printf("\n");
		}

		if(ControlData.DeviceRequest.wIndex == SETUP_DMA_REQUEST &&
			ControlData.DeviceRequest.wValue == 0 &&
			ControlData.DeviceRequest.wLength == 6)
			setup_dma_request();
		else if(ControlData.DeviceRequest.wIndex == GET_SET_TWAIN_REQUEST)
			set_twain_request();
		else
			stall_ep0();
	}	// if write register
}

