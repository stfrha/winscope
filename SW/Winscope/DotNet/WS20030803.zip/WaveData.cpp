// WaveData.cpp: implementation of the CWaveData class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Winscope.h"
#include "WaveData.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CWaveData::CWaveData()
{

}

CWaveData::~CWaveData()
{

}
